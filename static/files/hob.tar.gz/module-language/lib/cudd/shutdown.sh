#! /bin/sh
rm -rf include lib *.bak *~

