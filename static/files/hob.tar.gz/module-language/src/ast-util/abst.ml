open Aabsyn

let collect_all_sets ast = 
  List.map fst ast.set_defns

let collect_all_bools ast = 
  ast.pred_vars

let rec fetch_local_set_type s m =
  let sd = (List.find (fun x -> fst x = s) m.set_defns) in
  let rec _fetch f = match f with
  | IdForm id -> fetch_local_set_type id m
  | BaseForm b -> b.xt
  | UnionForm (l, _) -> _fetch l
  | IntersectionForm (l, _) -> _fetch l
  in _fetch (snd sd)
         
