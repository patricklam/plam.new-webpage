open Sabsyn

type sets_and_bools = {
    s : Id.var_t list;
    b : Id.var_t list;
  }

(* needs to change when we add calls to methods. *)
let collect_called_modules ast =
  List.concat (List.map (fun x -> x.calls) ast.procs)

(* collects all foos which are not hidden from m *)
let collect_all_foo (m:Sabsyn.spec_module) fn =
  let m_scopes = Scopes.scopes_of m.module_name in
  let all_specs = List.map (fun x -> x.Sabsyn.module_name) !Ast.spec in
  let candidates = List.filter
      (fun m'_name -> 
        let m' = Ast.fetch_spec m'_name in
        let m'_scopes = Scopes.scopes_of m'.module_name in
        let scope_difference = Util.difference m'_scopes m_scopes in
        not (List.exists (fun x -> x) (List.map (fun x -> not (List.mem m'.module_name x.Sabsyn.exports)) scope_difference)))
      all_specs in
  List.concat (List.map (fun x -> fn x (Ast.fetch_spec x)) candidates)
      
let collect_all_sets ast = 
  collect_all_foo ast 
    (fun mn x -> 
      let s = List.map fst 
          (List.filter (fun y -> not (snd y = Types.TBool)) x.specvars) in
      (List.map (Util.qualify_if_needed mn) s))

let collect_all_bools ast = 
  collect_all_foo ast 
    (fun mn x -> 
      let s = List.map fst 
          (List.filter (fun y -> snd y = Types.TBool) x.specvars) in
      (List.map (Util.qualify_if_needed mn) s))

(* This really collects all defaults in the program, not just in scope. *)
let collect_all_defaults ast =
  List.concat (List.map (fun x -> (Ast.fetch_spec x).Sabsyn.defaults) 
                 (Ast.all_spec_modules ())) @
  List.concat (List.map (fun x -> x.Sabsyn.scope_defaults) 
                 (Scopes.all_scopes ()))

(* return all sets in scope *)
let collect_sets_types ast : (string * Types.value_type) list = 
  collect_all_foo ast 
    (fun mn x -> 
      (List.concat (List.map (fun (x, y0) -> 
        match y0 with
          Types.TSet y -> [Util.qualify_if_needed mn x, y]
        | _ -> []) x.specvars)))

let collect_vars form = 
  let empty = { s = []; b = []; } in
  let fetch_s sb = sb.s in
  let fetch_b sb = sb.b in
  let combine sl sr = 
    { s = sl.s @ sr.s;
      b = sl.b @ sr.b } in
  let rec collect_setexp s =
    match s with
    | Prevar i
    | Postvar i -> { s = [i]; b = []; }
    | Emptyset -> empty
    | Union sel 
    | Inter sel -> 
        let ss = List.map collect_setexp sel in
        { s = List.concat (List.map fetch_s ss);
          b = List.concat (List.map fetch_b ss); }
    | Diff (l, r) -> 
        let sl = collect_setexp l in
        let sr = collect_setexp r in
        combine sl sr in
  let rec collect_atom a =
    match a with
    | Eq (l, r) 
    | Neq (l, r)
    | Sub (l, r) -> 
        let sl = collect_setexp l in
        let sr = collect_setexp r in
        combine sl sr 
    | True -> empty
    | False -> empty
    | Cardeq (se, i) 
    | Cardleq (se, i)
    | Cardgeq (se, i) -> collect_setexp se
    | Disjoint sel -> 
        let ss = List.map collect_setexp sel in
        { s = List.concat (List.map fetch_s ss);
          b = List.concat (List.map fetch_b ss); }
    | Propvar i -> { s = []; b = [i]; }
    | Propvarpost i -> { s = []; b = [i]; }
  and collect_form f =
    match f with
    | Atom af -> collect_atom af
    | Not nf -> collect_form nf
    | And fl 
    | Or fl -> 
        let ss = List.map collect_form fl in
        { s = List.concat (List.map fetch_s ss);
          b = List.concat (List.map fetch_b ss); }
    | Impl (p, c) 
    | Iff (p, c) -> 
        let sl = collect_form p in
        let sr = collect_form c in
        combine sl sr
    | ExistsOne ((v, t), f) 
    | ForallOne ((v, t), f) 
    | ExistsSet ((v, t), f) 
    | ForallSet ((v, t), f) -> 
        let ss = collect_form f in
        { s = List.filter (fun x -> x <> v) ss.s;
          b = ss.b; }
    | ExistsProp (v, f) 
    | ForallProp (v, f) ->
        let ss = collect_form f in
        { s = ss.s; 
          b = List.filter (fun x -> x <> v) ss.b; }
    | UninterpretedString _ -> { s = []; b = []; } in
  collect_form form

let parse_formula mn all_sb s =
  let unsome = function (Some x) -> x 
    | None -> failwith "tried to unsome None" in
  let l = Speclanguage.Lexer.create_from_string "[formula]"
      ("formula "^ (Util.trim_quotes s)) in
  let p = Speclanguage.Parser.create l in
  let ast = Speclanguage.Parser.parse p in
  match ast with
    Speclanguage.Nodes.Start (Speclanguage.Nodes.PFile 
                            (Speclanguage.Nodes.AFormFile n), _) -> 
                              Deuglifyspec.convert_form mn all_sb.s all_sb.b
                                (unsome n.Speclanguage.Nodes.form_file_form)
  | _ -> failwith "bad AST in Spec"

let rec fetch_set_type s m =
  if (String.contains s '.') then (* remote *)
   let dot = String.index s '.' in
   let modn = Str.string_before s dot in
   let nm = Str.string_after s (dot+1) in
   fetch_set_type nm (Ast.fetch_spec modn)
  else (* local *)
   snd (List.find (fun x -> fst x = s) m.specvars)

(* returns true iff proc p transitively calls module m *)
let compute_proc_transitively_calls (p:Sabsyn.proc_spec) (m:Id.module_t) =
  (* would be nice if we had call info at proc, not module, level *)
  let visited_callees = ref [] in
  let rec visit (c:Sabsyn.spec_module) = 
    visited_callees := c.Sabsyn.module_name :: !visited_callees;
    (* here's where we look at all procs in module... *)
    List.exists 
      (fun x -> 
        let xm = Id.module_of_proc x.Sabsyn.proc_name in
        if xm = m then 
          true
        else
          if (not (List.mem xm !visited_callees)) then
            visit (Ast.fetch_spec xm)
          else
            false)
      c.Sabsyn.procs in
  List.exists visit (List.map Ast.fetch_spec
                       (Util.remove_dups p.Sabsyn.calls))

let compute_module_transitively_calls (m:Id.module_t) (m':Id.module_t) =
  List.exists (fun x -> compute_proc_transitively_calls x m')
    (Ast.fetch_spec m).Sabsyn.procs

let proc_module_callgraph : (Id.proc_t, Id.module_t list) Hashtbl.t = 
  Hashtbl.create 0
let proc_module_transitive_callgraph 
    : (Id.proc_t, Id.module_t list) Hashtbl.t = 
  Hashtbl.create 0
let module_callgraph : (Id.module_t, Id.module_t list) Hashtbl.t =
  Hashtbl.create 0
let module_transitive_callgraph : (Id.module_t, Id.module_t list) Hashtbl.t =
  Hashtbl.create 0

let is_proc_transitive_caller_of (p:Sabsyn.proc_spec) (m:Id.module_t) =
  List.mem m (Hashtbl.find proc_module_transitive_callgraph p.Sabsyn.proc_name)

let is_mod_transitive_caller_of (m:Id.module_t) (m':Id.module_t) =
  List.mem m' (Hashtbl.find module_transitive_callgraph m)

let compute_callgraphs () =
  List.iter (fun ms -> List.iter (fun p -> 
    let pn = p.Sabsyn.proc_name in
    let pnm = Id.module_of_proc pn in
    Hashtbl.add proc_module_callgraph pn p.Sabsyn.calls;
    let m = if (Hashtbl.mem module_callgraph pnm) then
      Hashtbl.find module_callgraph pnm else [] in
    Hashtbl.replace module_callgraph pnm (p.Sabsyn.calls @ m)) 
      ms.Sabsyn.procs) 
    !Ast.spec;
  (* then, transitively close module_callgraph *)
  let mods = Ast.all_spec_modules () in
  List.iter (fun x -> 
    let mc = List.filter 
        (fun y -> compute_module_transitively_calls x y) mods in
    Hashtbl.add module_transitive_callgraph x mc)
    mods;
  List.iter (fun x0 -> 
    let x = Ast.fetch_spec x0 in
    List.iter (fun p -> 
      let mc = List.filter 
          (fun y -> compute_proc_transitively_calls p y) mods in
      Hashtbl.add proc_module_transitive_callgraph p.proc_name mc)
      x.procs) 
    mods

let shield_params ps f =
  List.fold_left (fun x (y,t) -> 
    match t with
    | Types.TBool -> ExistsProp (y, x) 
    | _ -> ExistsSet ((y,t),x))
    f (List.concat 
         [(match ps.ret_val with None -> []
         | Some x -> [x]) @ ps.formals])
