(* Compute weakest preconditions *)

open Iabsyn
open Vcform
open Vctrans

type stmt = Vcform.form Iabsyn.stmt

let initial_value (t:Types.value_type) (v:Id.var_t) = 
(* Gives formula saying v has initial value;
   should overapproximate Iabsyn.initial_value. *)
  let eq f = mk_eq(mk_var v, f) in
  match t with
  | Types.TInt -> eq (mk_int 0)
  | Types.TBool -> eq mk_false
  | Types.TFloat|Types.TString|Types.TChar|Types.TByte|Types.TVoid -> mk_true
  | Types.TObj _ -> eq mk_null
  | Types.TArray _ -> mk_eq(mk_arraySize (mk_var v),mk_int 0)
  | Types.TTuple _|Types.TSet _ -> mk_true

let assign modn (v:ident) (rhs:Iabsyn.expr) (f:Vcform.form) =  
  let (vc_rhs,pre) = vcexpr_of_iabsyn modn rhs in 
  mk_and [prime_all pre;subst [(primed v,prime_all vc_rhs)] f]

let functionUpdate (typeOfUpdate:constValue) (modn:string) (v:ident) (vc_ind:Vcform.form) (rhs:Iabsyn.expr) (f:Vcform.form) =
  let (vc_rhs,pre) = vcexpr_of_iabsyn modn rhs in
  let vc_functionUpdate = prime_all (mk_functionUpdate(typeOfUpdate,mk_var v,vc_ind,vc_rhs)) in
  mk_and [prime_all pre;subst [(primed v,vc_functionUpdate)] f]

let arrayAssign (modn:string) (v:ident) (ind:Iabsyn.expr) (rhs:Iabsyn.expr) (f:Vcform.form) =
  let (vc_ind,pre) = vcexpr_of_iabsyn modn ind in
  let vc_ind' = prime_all vc_ind in
  let boundsCheck = mk_and[mk_lteq(mk_int 0, vc_ind');
                           mk_lt(vc_ind',mk_arraySize (mk_var v))] in
  mk_and [prime_all pre;
          boundsCheck;
          functionUpdate ArrayWrite modn v vc_ind rhs f]

let fieldAssign (modn:string) (field:ident) (lhs:Iabsyn.expr) (rhs:Iabsyn.expr) (f:Vcform.form) = 
  let (vc_lhs,pre) = vcexpr_of_iabsyn modn lhs in
  let nullCheck = mk_neq(prime_all vc_lhs, mk_null) in
  mk_and [prime_all pre;
          nullCheck;
          functionUpdate FieldWrite modn field vc_lhs rhs f]

let rec wp_expr modn (e:expr) (f:form) : form =
  match e with
    | AssignExpr(LocalLvalue v,rhs) -> 
        assign modn (mk_local_var v) rhs f
    | AssignExpr(RefLvalue v,rhs) -> 
        assign modn (mk_global_var modn v) rhs f
    | AssignExpr(ArrayLvalue(VarExpr (LocalLvalue v),e2),rhs) -> 
        arrayAssign modn (mk_local_var v) e2 rhs f
    | AssignExpr(ArrayLvalue(VarExpr (RefLvalue v),e2),rhs) -> 
        arrayAssign modn (mk_global_var modn v) e2 rhs f
    | AssignExpr(FieldLvalue(base,fld),rhs) ->
        fieldAssign modn (mk_global_var modn (Id.name_of_field fld)) base rhs f
    | AssignExpr(_,_) ->
        failwith "Vcwp.wp_expr: assignment expression not simple enough"
    | InvokeExpr(p,es) -> 
        Util.warn ("Vcwp.wp_expr: Ignored procedure call to " ^ Id.name_of_proc p); f
    | _ -> Util.warn
         ("Vcwp.wp_expr: don't know how to handle expression " ^ 
         Iabsynprinter.string_of_expr e); f

let rec wp modn (s:stmt) (f:form) : form =   
  let rec lwp s f = match s with
  | EmptyStmt -> f
  | ChoiceStmt(s1,s2) -> Vcform.smk_and [wp1 s1 f; wp1 s2 f]
  | LocalDeclStmt (v,t,init_val) -> 
      assign modn (mk_local_var v) init_val f
  | ExprStmt e -> wp_expr modn e f
  | CompoundStmt ss -> List.fold_right wp1 ss f
  | AssertStmt(s,f1) -> smk_and [f1; f]
  | AssumeStmt(s,f1) -> smk_impl(f1,f)
  | HavocStmt vs -> 
      let add id = (primed id,TypeVoid) in 
      let add_typ_prim ids = List.map add ids in
      smk_foralls(add_typ_prim vs,f)
  | PragmaStmt _ -> f
  | (ReturnStmt _|WhileStmt(_,_,_)|IfStmt(_,_,_)) ->
      failwith "Vcwp.wp: Found a statement that should have been desugared"
  and wp1 s f = let r = lwp s f in begin
    (*
    print_string ("\nPOST FORMULA:\n" ^ Vcprint.isabelle_formula f);
    print_string ("\nSTATEMENT:\n" ^ Iabsynprinter.pstmt 2 Vcprint.isabelle_formula s);
    print_string ("WEAKEST PRECONDITION = " ^ Vcprint.isabelle_formula r ^ "\n");
     *)
    r
  end
  in wp1 s f
