
let parsing_debug = ref true

let parse_formula s =
  let buff = Lexing.from_string s in begin
    Vcformparsing.input := Some s;
    Vcformparsing.buffer := Some buff;
    (if !parsing_debug then Util.msg ("About to lex+parse: " ^ s) else ());
    let res = Vcformparse.main Vcformlex.token buff in
    (if !parsing_debug then Util.msg (" -- done.\n") else ());
    res
  end
