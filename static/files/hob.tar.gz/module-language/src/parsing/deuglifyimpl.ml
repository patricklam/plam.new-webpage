open Formatlanguage
open Nodes
open Iabsyn
open Types

let unsome = function (Some x) -> x | None -> failwith "[deuglifyimpl] tried to deoptionify None"

let rec value_type_from_ugly x =
  match x with
  | AIntType _ -> TInt
  | AFloatType _ -> TFloat
  | ABoolType _ -> TBool
  | ACharType _ -> TChar
  | AByteType _ -> TByte
  | AStringType _ -> TString
  | AFormatType f -> TObj (Tokens.getText (unsome f.format_type_identifier))
  | AArrayType a -> 
      let rec stackers base_type a' = 
        match a' with
        | AOneDims _ -> base_type
        | AManyDims a'' -> stackers (TArray base_type) (unsome a''.many_dims_dims)
      in (TArray (stackers (value_type_from_ugly (unsome a.array_type_type)) (unsome a.array_type_dims)))

let format_name_from_ugly x =
  match x with
  | AFormatType f -> Id.fetch_format 
        (Tokens.getText (unsome f.format_type_identifier))
  | _ -> failwith "a primitive type"

let format_pos_from_ugly x =
  match x with
  | AFormatType f -> 
        (Tokens.getPos (unsome f.format_type_identifier))
  | _ -> failwith "a primitive type"

let rec local_decl_regularizer = 
  let parent_replacements = Hashtbl.create 0 in
  {
  Analysis.override = (fun parent n -> n);
     Analysis.enter = (fun parent n -> local_decl_regularizer);
     Analysis.leave = (fun parent old_child child v -> 
       match child with
     | P (PStmt c') ->
         (match c' with 
         | ALocalDefStmt m -> 
             if (List.length m.local_def_stmt_lnameval <= 1) then child else
             begin
               let t = m.local_def_stmt_type in
               let replacement_defs = List.map
                   (fun x -> 
                     ALocalDefStmt 
                       { local_def_stmt_type = t; 
                         local_def_stmt_lnameval = [x]; }
                   )
                   m.local_def_stmt_lnameval in
               let extant_f = 
                 if Hashtbl.mem parent_replacements parent then 
                   Hashtbl.find parent_replacements parent
                 else (fun x -> x) in
               (match parent with
               | P (PStmt (ACompoundStmt cs)) ->
                   let repl lst = List.concat (List.map (fun x ->
                     if x = c' then (* hee hee! [1] *)
                       replacement_defs
                     else [x]) lst) in
                   Hashtbl.replace parent_replacements parent 
                     (fun y -> 
                       match y with 
                       | P (PStmt (ACompoundStmt cs0)) ->
                           extant_f (P (PStmt (ACompoundStmt { compound_stmt_stmt = repl cs0.compound_stmt_stmt })))
                       | _ -> failwith "blubblub0")
               | P (PStmt (AIfElseStmt is)) -> 
                   Hashtbl.replace parent_replacements parent 
                     (fun y -> match y with 
                     | P (PStmt (AIfElseStmt is0)) -> 
                         let expr = P (PExpr (unsome is0.if_else_stmt_expr)) in
                         let then_clause = is0.if_else_stmt_then_stmt in
                         let is' = 
                           (P (PStmt (ACompoundStmt 
                                        {compound_stmt_stmt = 
                                         replacement_defs}))) in
                         extant_f 
                           (P (PStmt (AIfElseStmt 
                                        (if (c' == (unsome then_clause)) then
                                          a_if_else_stmt 
                                            expr is' (P (PStmt 
                                                           (unsome is0.if_else_stmt_else_stmt)))
                                        else
                                          a_if_else_stmt 
                                            expr (P (PStmt 
                                                       (unsome is0.if_else_stmt_then_stmt)))
                                            is'))))
                     | _ -> failwith "blubblub1")
               | P (PStmt (AIfStmt is)) -> 
                   Hashtbl.replace parent_replacements parent 
                     (fun y -> match y with
                     | P (PStmt (AIfStmt is0)) -> 
                         let expr = P (PExpr (unsome is0.if_stmt_expr)) in
                         let is' = (P (PStmt (ACompoundStmt 
                                                {compound_stmt_stmt = replacement_defs}))) in
                         extant_f
                           (P (PStmt (AIfStmt (a_if_stmt expr is'))))
                     | _ -> failwith "blubblub2")
               | P (PStmt (AWhileStmt ws)) -> 
                   Hashtbl.replace parent_replacements parent 
                     (fun y -> match y with
                     | P (PStmt (AWhileStmt ws0)) -> 
                         let loop_inv = match ws0.while_stmt_inv with 
                           Some i -> T i | None -> Null_Node in
                         let expr = P (PExpr (unsome ws0.while_stmt_expr)) in
                         let ws' = (P (PStmt (ACompoundStmt 
                                                {compound_stmt_stmt = replacement_defs}))) in
                         extant_f (P (PStmt (AWhileStmt 
                                               (a_while_stmt loop_inv expr ws'))))
                     | _ -> failwith "blubblub3")
               | _ -> failwith "should not happen"); child
             end
         | _ -> 
             if Hashtbl.mem parent_replacements old_child then
               let f = Hashtbl.find parent_replacements old_child in
               f child
             else
               child)
     | _ -> child);
     Analysis.start = (fun () -> local_decl_regularizer);
    Analysis.finish = (fun n -> ());
}

(* [1] at first thought, one might suspect that structural equality is
not quite what we want: what if we replace the 'wrong statement'?
However, some cleverness reveals that since our replacement is fully
deterministic and replaces all instances of c' by replacement_defs, 
then you can actually use structural equality successfully. *)

let regularize_local_decls x =
  Analysis.visit_edge local_decl_regularizer
                       Nodes.Null_Node x 

let d x = Tokens.getText (unsome x)

let rec convert (mdl0:p_impl_module) : string impl_module = 
  let fn = Hashtbl.find Uglyast.impl_to_fn (P (PImplModule mdl0)) in
  let convert_declaring_module 
      mn mdl_members = 
    let convert_literal (q:p_literal) : (value * Ast.pos) = 
      let w = function x -> (Int (Int32.of_string (d x)), 
                             (fn, Tokens.getPos (unsome x))) in
        match q with
          | AIntLiteral il -> (match unsome il.int_literal_integer_literal with
                                 | ADecIntegerLiteral dil -> 
                                     w dil.dec_integer_literal_decimal_integer_literal
                                 | AHexIntegerLiteral hil -> 
                                     w hil.hex_integer_literal_hex_integer_literal
                                 | AOctIntegerLiteral hil -> 
                                     w hil.oct_integer_literal_octal_integer_literal)
          | AFloatLiteral fl -> 
              let f = unsome fl.float_literal_floating_point_literal in
                (Float (float_of_string (Tokens.getText f)), (fn, Tokens.getPos f))
          | ABoolLiteral bl -> let b = unsome bl.bool_literal_boolean_literal in
              (match b with
                 | ATrueBooleanLiteral _ -> (Bool true, (fn, "[?, ?]"))
                 | AFalseBooleanLiteral _ -> (Bool false, (fn, "[?, ?]")))
          | ACharLiteral cl -> 
              let c = unsome cl.char_literal_character_literal in
                (Char (String.get (Tokens.getText c ) 1), 
                 (fn, Tokens.getPos c))
          | AStringLiteral sl -> 
              let s = unsome sl.string_literal_string_literal in
                (String (Util.unescaped 
                           (Util.trim_quotes (Tokens.getText s))),
                 (fn, Tokens.getPos s))
          | ANullLiteral nl -> (null_obj, (fn, "[?, ?]")) in
    let rec convert_stmt : p_stmt -> string stmt = fun stm ->
      (match stm with
         | AEmptyStmt _ -> EmptyStmt
         | ACompoundStmt cs -> 
             CompoundStmt (List.map convert_stmt cs.compound_stmt_stmt)
         | ALocalDefStmt ds ->
             (* ds only has one definition *)
             let (ALnameValPair lv) = List.hd ds.local_def_stmt_lnameval in
             let lvname = d lv.lname_val_pair_identifier in
             let ct = value_type_from_ugly (unsome ds.local_def_stmt_type) in
             let lvval = match lv.lname_val_pair_expr with
               | None -> LiteralExpr (Iabsyn.initial_value ct)
               | Some y -> convert_expr y in
               LocalDeclStmt (lvname, ct, lvval)
         | AExprStmt es -> ExprStmt (convert_expr (unsome es.expr_stmt_expr))
         | AReturnStmt rs -> 
             (match rs.return_stmt_expr with
                  Some rv -> ReturnStmt (Some (convert_expr rv))
                | None -> ReturnStmt None)
         | AWhileStmt ws ->
             let i = match ws.while_stmt_inv with 
                 Some x -> Some (Tokens.getText x) | None -> None in
               WhileStmt (i,
                          convert_expr (unsome ws.while_stmt_expr),
                          convert_stmt (unsome ws.while_stmt_body))
         | AForStmt fs ->
             let i = match fs.for_stmt_inv with 
                 Some x -> Some (Tokens.getText x) | None -> None in
               CompoundStmt 
                 [ExprStmt (convert_expr (unsome fs.for_stmt_init));
                  WhileStmt (i, 
                             convert_expr (unsome fs.for_stmt_cond),
                             CompoundStmt 
                               [convert_stmt (unsome fs.for_stmt_stmt);
                                ExprStmt (convert_expr (unsome fs.for_stmt_iter))])]
         | AAssertStmt asst -> (match asst.assert_stmt_n with
                                  | None -> AssertStmt (None, d asst.assert_stmt_string_literal)
                                  | Some n' -> AssertStmt (Some (Tokens.getText n'), 
                                                           d asst.assert_stmt_string_literal))
         | AAssumeStmt assm -> (match assm.assume_stmt_n with
                                  | None -> AssumeStmt (None, d assm.assume_stmt_string_literal)
                                  | Some n' -> AssumeStmt (Some (Tokens.getText n'), 
                                                           d assm.assume_stmt_string_literal))
         | APragmaStmt ps -> PragmaStmt (Util.trim_quotes (d ps.pragma_stmt_string_literal))
         | AChoiceStmt cs -> ChoiceStmt (convert_stmt (unsome cs.choice_stmt_a),
                                         convert_stmt (unsome cs.choice_stmt_b))
         | AHavocStmt ids -> HavocStmt (List.map Tokens.getText ids.havoc_stmt_identifier)
         | AIfElseStmt is ->
             IfStmt ((convert_expr (unsome is.if_else_stmt_expr)),
                     convert_stmt (unsome is.if_else_stmt_then_stmt),
                     convert_stmt (unsome is.if_else_stmt_else_stmt))
         | AIfStmt is ->
             IfStmt ((convert_expr (unsome is.if_stmt_expr)),
                     convert_stmt (unsome is.if_stmt_then_stmt),
                     EmptyStmt)
      )
    and convert_name_expr_to_proc_t (exp:p_expr) : (Id.proc_t * Ast.pos) = 
      match exp with
        | ASimpleNameExpr e -> 
            (Id.fetch_proc mn (d e.simple_name_expr_n), 
             (fn, Tokens.getPos (unsome e.simple_name_expr_n)))
        | AQualifiedNameExpr e -> 
            (match unsome e.qualified_name_expr_m with
               | ASimpleNameExpr e' -> 
                   (Id.fetch_proc 
                      (d e'.simple_name_expr_n) (d e.qualified_name_expr_n),
                    (fn, Tokens.getPos (unsome e'.simple_name_expr_n)))
               | AQualifiedNameExpr e' -> 
                   failwith ("badly formed name "^(d e'.qualified_name_expr_n)^" at "^
                               fn ^ " " ^ 
                               (Tokens.getPos (unsome e'.qualified_name_expr_n)))
               | _ -> failwith "badly formed name")
        | AFieldAccessExpr e -> 
            (match unsome e.field_access_expr_b with
               | ASimpleNameExpr e' -> 
                   (Id.fetch_proc 
                      (d e'.simple_name_expr_n) (d e.field_access_expr_n),
                    (fn, Tokens.getPos (unsome e'.simple_name_expr_n)))
               | AQualifiedNameExpr e' -> 
                   failwith ("badly formed name "^(d e'.qualified_name_expr_n)^" at "^
                               fn ^ " " ^ 
                               (Tokens.getPos (unsome e'.qualified_name_expr_n)))
               | _ -> failwith "badly formed name")
        | _ -> failwith "not a name"
    and convert_expr_to_lvalue (exp:p_expr) : (lvalue * Ast.pos) =
      match exp with (* it's a left_hand_side *)
        | AFieldAccessExpr e -> 
            let b = convert_expr (unsome e.field_access_expr_b) in
              (FieldLvalue (b, Id.fetch_field mn (d e.field_access_expr_n)),
               Exprtbl.find Ast.expr_pos b)
        | AArrayAccessExpr e -> 
            let b = convert_expr (unsome e.array_access_expr_b) in
              (ArrayLvalue (b,
                            convert_expr (unsome e.array_access_expr_i)),
               Exprtbl.find Ast.expr_pos b)
        | ASimpleNameExpr e -> 
            let n = e.simple_name_expr_n in
              (LocalLvalue (d n),
               (fn, Tokens.getPos (unsome n)))
                (* this could also be a RefLvalue; convert later. *)
        | _ -> failwith "bad lvalue"
    and convert_expr (exp:p_expr) : expr = 
      let rv = real_convert_expr exp in
        Exprtbl.add Ast.expr_pos (fst rv) (snd rv);
        fst rv
    and real_convert_expr (exp:p_expr) : (expr * Ast.pos) =
      match exp with 
        | ALiteralExpr e -> 
            let c = convert_literal (unsome e.literal_expr_literal) in
              (LiteralExpr (fst c), snd c)
        | AQualifiedNameExpr e -> failwith "should have been converted"
        | ASimpleNameExpr e -> 
            let n = unsome e.simple_name_expr_n in
              (VarExpr (LocalLvalue (Tokens.getText n)), (fn, Tokens.getPos n))
        | AFieldAccessExpr e -> 
            let b = convert_expr (unsome e.field_access_expr_b) in
            let n = d e.field_access_expr_n in
            let nf = Id.fetch_field mn n in
              if (n = "length") then
                (ArrayLengthExpr b, Exprtbl.find Ast.expr_pos b)
              else
                (FieldAccessExpr (b, nf), Exprtbl.find Ast.expr_pos b)
        | AArrayAccessExpr e -> 
            let b = convert_expr (unsome e.array_access_expr_b) in
              (ArrayAccessExpr (b, convert_expr (unsome e.array_access_expr_i)),
               Exprtbl.find Ast.expr_pos b)
        | ANewExpr e -> 
            let t = unsome (e.new_expr_type) in
            let nt = format_name_from_ugly t in
              (NewExpr nt, (fn, format_pos_from_ugly t))
        | ANewarrayExpr ne -> 
            let t = value_type_from_ugly (unsome ne.newarray_expr_type) in
            let e = List.map convert_expr ne.newarray_expr_expr in
            let rec ddc m =
              match m with 
                  AOneDims _ -> 1
                | AManyDims m -> 1 + ddc (unsome m.many_dims_dims) in
            let dims = (match ne.newarray_expr_dims with
                          | None -> 0
                          | Some d' -> ddc d') in
              (NewArrayExpr (t, e, dims), Exprtbl.find Ast.expr_pos (List.nth e 0))
        | AInvokeExpr e -> 
            let b = convert_name_expr_to_proc_t (unsome e.invoke_expr_expr) in
              (InvokeExpr (fst b, List.map convert_expr e.invoke_expr_actuals),
               snd b)            
        | AAssignExpr e -> 
            let l = convert_expr_to_lvalue (unsome e.assign_expr_l) in
              (AssignExpr 
                 (fst l, convert_expr (unsome e.assign_expr_r)), snd l)
        | APreincExpr e -> 
            let l = convert_expr_to_lvalue (unsome e.preinc_expr_expr) in
              (PreIncExpr (fst l), snd l)
        | APredecExpr e -> 
            let l = convert_expr_to_lvalue (unsome e.predec_expr_expr) in
              (PreDecExpr (fst l), snd l)
        | APostincExpr e -> 
            let l = convert_expr_to_lvalue (unsome e.postinc_expr_expr) in
              (PostIncExpr (fst l), snd l)
        | APostdecExpr e -> 
            let l = convert_expr_to_lvalue (unsome e.postdec_expr_expr) in
              (PostDecExpr (fst l), snd l)
        | ANegExpr e -> 
            let n = convert_expr (unsome e.neg_expr_expr) in
              (NegExpr n,
               Exprtbl.find Ast.expr_pos n)
        | APlusExpr e  -> 
            let l = convert_expr (unsome e.plus_expr_l) in
              (PlusExpr (l, convert_expr (unsome e.plus_expr_r)),
               Exprtbl.find Ast.expr_pos l)
        | AMinusExpr e -> 
            let l = convert_expr (unsome e.minus_expr_l) in
              (MinusExpr (l, convert_expr (unsome e.minus_expr_r)),
               Exprtbl.find Ast.expr_pos l)
        | AMultExpr e  -> 
            let l = convert_expr (unsome e.mult_expr_l) in
              (MultExpr (l, convert_expr (unsome e.mult_expr_r)),
               Exprtbl.find Ast.expr_pos l)
        | ADivExpr e   -> 
            let l = convert_expr (unsome e.div_expr_l) in
              (DivExpr (l, convert_expr (unsome e.div_expr_r)),
               Exprtbl.find Ast.expr_pos l)
        | AModExpr e   -> 
            let l = convert_expr (unsome e.mod_expr_l) in
              (ModExpr (l, convert_expr (unsome e.mod_expr_r)),
               Exprtbl.find Ast.expr_pos l)
        | AConditionalAndExpr e -> 
            let l = convert_expr (unsome e.conditional_and_expr_l) in
              (AndExpr (l, convert_expr (unsome e.conditional_and_expr_r)),
               Exprtbl.find Ast.expr_pos l)
        | AConditionalOrExpr e -> 
            let l = convert_expr (unsome e.conditional_or_expr_l) in
              (OrExpr (l, convert_expr (unsome e.conditional_or_expr_r)),
               Exprtbl.find Ast.expr_pos l)
        | AAndExpr e -> 
            let l = convert_expr (unsome e.and_expr_l) in
              (BitAndExpr (l, convert_expr (unsome e.and_expr_r)),
               Exprtbl.find Ast.expr_pos l)
        | AInclusiveOrExpr e -> 
            let l = convert_expr (unsome e.inclusive_or_expr_l) in
              (BitOrExpr (l, convert_expr (unsome e.inclusive_or_expr_r)),
               Exprtbl.find Ast.expr_pos l)
        | AExclusiveOrExpr e -> 
            let l = convert_expr (unsome e.exclusive_or_expr_l) in
              (BitXorExpr (l, convert_expr (unsome e.exclusive_or_expr_r)),
               Exprtbl.find Ast.expr_pos l)
        | ANotExpr e -> 
            let n = convert_expr (unsome e.not_expr_expr) in
              (NotExpr n, Exprtbl.find Ast.expr_pos n)
        | AEqExpr e -> 
            let l = convert_expr (unsome e.eq_expr_l) in
              (EqExpr (l, convert_expr (unsome e.eq_expr_r)),
               Exprtbl.find Ast.expr_pos l)
        | ANeqExpr e -> 
            let l = convert_expr (unsome e.neq_expr_l) in
              (NeqExpr (l, convert_expr (unsome e.neq_expr_r)),
               Exprtbl.find Ast.expr_pos l)
        | ALtExpr e -> 
            let l = convert_expr (unsome e.lt_expr_l) in
              (LtExpr (l, convert_expr (unsome e.lt_expr_r)),
               Exprtbl.find Ast.expr_pos l)
        | AGtExpr e -> 
            let l = convert_expr (unsome e.gt_expr_l) in
              (GtExpr (l, convert_expr (unsome e.gt_expr_r)),
               Exprtbl.find Ast.expr_pos l)
        | ALteqExpr e -> 
            let l = convert_expr (unsome e.lteq_expr_l) in
              (LteqExpr (l, convert_expr (unsome e.lteq_expr_r)),
               Exprtbl.find Ast.expr_pos l)
        | AGteqExpr e -> 
            let l = convert_expr (unsome e.gteq_expr_l) in
              (GteqExpr (l, convert_expr (unsome e.gteq_expr_r)),
               Exprtbl.find Ast.expr_pos l)
        | AShiftLeftExpr e -> 
            let l = convert_expr (unsome e.shift_left_expr_l) in
              (ShiftLeftExpr (l, convert_expr (unsome e.shift_left_expr_r)),
               Exprtbl.find Ast.expr_pos l)
        | ASignedShiftRightExpr e -> 
            let l = convert_expr (unsome e.signed_shift_right_expr_l) in
              (SignedShiftRightExpr 
                 (l, convert_expr (unsome e.signed_shift_right_expr_r)),
               Exprtbl.find Ast.expr_pos l)
        | AUnsignedShiftRightExpr e -> 
            let l = convert_expr (unsome e.unsigned_shift_right_expr_l) in
              (UnsignedShiftRightExpr
                 (l, convert_expr (unsome e.unsigned_shift_right_expr_r)),
               Exprtbl.find Ast.expr_pos l) in
    let convert_format : p_format_decl -> format_decl = fun (AFormatDecl f) ->
      let convert_format_member (AFormatMember fm) = 
        List.map (fun m -> ((Id.fetch_field mn (Tokens.getText m)),
                            value_type_from_ugly (unsome fm.format_member_type)))
          fm.format_member_member in
        { format_name = d f.format_decl_identifier;
          fields = List.concat (List.map 
                                  convert_format_member 
                                  f.format_decl_format_member); } in
    let convert_ref (r0:p_ref_decl) : (Id.var_t * value_type) = 
      match r0 with (ARefDecl r) ->
        (d r.ref_decl_ref, value_type_from_ugly (unsome r.ref_decl_type)) in
    let convert_proc : p_proc_decl -> string proc_def = fun (AProcDecl p) -> 
      let convert_formal (AFormal f) = 
        (Id.fetch_var (d f.formal_fname), 
         value_type_from_ugly (unsome f.formal_type)) in
        {
          proc_id = Id.fetch_proc mn (d p.proc_decl_identifier);
          proc_modifiers = { 
            Id.is_private = match (p.proc_decl_private) with
              | None -> false | Some _ -> true; };
          formals = List.map convert_formal p.proc_decl_formal;
          ret_val = (match p.proc_decl_returns_decl with 
                       | None -> None
                       | Some (AReturnsDecl rv) -> 
                           Some (Id.fetch_var (d rv.returns_decl_rname), 
                                 value_type_from_ugly (unsome rv.returns_decl_type)));
          requires = (match p.proc_decl_requires with
                        | None -> None
                        | Some x -> Some (d p.proc_decl_requires));
          ensures = (match p.proc_decl_ensures with
                       | None -> None
                       | Some x -> Some (d p.proc_decl_ensures));
          modifies = (match p.proc_decl_modifies_decl with
                        | None -> []
                        | Some (AModifiesDecl md) ->
                            List.map (fun x -> Tokens.getText x) md.modifies_decl_identifier);
          proc_body = convert_stmt (unsome p.proc_decl_stmt) } in
    let select_formats m = match m with
        AFormatImplMember _ -> true | _ -> false in
    let select_refs m = match m with
        AReferenceImplMember _ -> true | _ -> false in
    let select_procs m = match m with
        AProcImplMember _ -> true | _ -> false in
      { 
        module_name = mn;
        instantiated_from = None; 
        param_subst = [];
        formats = List.map 
          (fun x -> match x with AFormatImplMember x' -> 
             convert_format (unsome x'.format_impl_member_format_decl) 
             | _ -> failwith "filter failed")
          (List.filter select_formats mdl_members);
        references = List.map
          (fun x -> match x with AReferenceImplMember x' -> 
             convert_ref (unsome x'.reference_impl_member_ref_decl) 
             | _ -> failwith "filter failed")
          (List.filter select_refs mdl_members);
        procs = List.map 
          (fun x -> match x with AProcImplMember x' -> 
             convert_proc (unsome x'.proc_impl_member_proc_decl) 
             | _ -> failwith "filter failed")
          (List.filter select_procs mdl_members);
      } in
    match regularize_local_decls (P (PImplModule mdl0)) with
        (P (PImplModule (AModuleImplModule c))) -> 
          let mn = Id.fetch_module (d c.module_impl_module_identifier) in
            Hashtbl.add Ast.impl_to_fn mn fn;
            convert_declaring_module mn c.module_impl_module_impl_member 
      | (P (PImplModule (AInstImplModule c))) ->  
          let mn = Id.fetch_module (d c.inst_impl_module_n) in
            Hashtbl.add Ast.impl_to_fn mn fn;
            { 
              module_name = mn;
              instantiated_from = Some
                (Id.fetch_format (d c.inst_impl_module_parent));
              param_subst = List.map (fun (ASubst x) -> 
                                        (Id.fetch_format (d x.subst_f),
                                         Id.fetch_format (d x.subst_a)))
                c.inst_impl_module_params;
              formats = []; (* we'll fill this later! *)
              references = []; 
              procs = [];
            }
      | _ -> failwith "bad module to convert" 
          

