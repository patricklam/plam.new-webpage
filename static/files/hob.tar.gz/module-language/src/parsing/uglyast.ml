(* Initial syntax trees obtained from parser *)

let spec_ast : Speclanguage.Nodes.node ref = 
  ref Speclanguage.Nodes.Null_Node
let abst_ast : Abstlanguage.Nodes.node ref = 
  ref Abstlanguage.Nodes.Null_Node
let impl_ast : Formatlanguage.Nodes.node ref =
  ref Formatlanguage.Nodes.Null_Node
let scope_ast : Speclanguage.Nodes.node ref =
  ref Speclanguage.Nodes.Null_Node
let impl_to_fn : (Formatlanguage.Nodes.node, string) Hashtbl.t = 
  Hashtbl.create 0

let unsome = function (Some x) -> x | None -> failwith "[uglyast] tried to deoptionify None"

open Speclanguage
open Nodes

let fetch_spec_ast n = 
  let l = Util.phase ("Lexing file "^n) 
      Speclanguage.Lexer.create n (open_in n) in
  let p = Speclanguage.Parser.create l in
  Util.phase "Parsing" Speclanguage.Parser.parse p

let d x = Tokens.getText (unsome x)

let parse_spec_asts source_names =
  let name2frag = Hashtbl.create 1 in
  let frags_so_far = ref [] in
  let parse n = 
    Util.phase ("module " ^ n)
      (Hashtbl.add name2frag n 
        (let ast_fragment = fetch_spec_ast n in
        (match ast_fragment with 
          Start (PFile (ASpecOrScopeFile af), _) ->
            frags_so_far := List.concat 
                (List.map 
                   (fun x ->
                     match x with
                     | ASpecSpecOrScope x1 -> 
                         let m = unsome (x1.spec_spec_or_scope_spec_module) in
                         (match m with
                           | AModSpecModule mm ->
                               Hashtbl.add Ast.spec_to_fn
                                 n (d mm.mod_spec_module_identifier)
                           | _ -> ());
                         [P (PSpecModule m)]
                     | AScopeSpecOrScope _ -> [])
                   af.spec_or_scope_file_spec_or_scope) @ 
              !frags_so_far
        | _ -> failwith "bad AST");
        ast_fragment))
  in begin
      List.iter parse source_names;
      (name2frag, P (PFile (ASpecOrScopeFile (a_spec_or_scope_file (List.map (fun x -> P (PSpecOrScope (ASpecSpecOrScope (a_spec_spec_or_scope x)))) !frags_so_far)))))
    end

let fetch_spec_module_foo fn fn1 = 
  let f = match !spec_ast with
    P (PFile (ASpecOrScopeFile n)) -> n.spec_or_scope_file_spec_or_scope
  | _ -> failwith "bad AST" in
  fn (fun m0 ->
    let m1 = match m0 with
      ASpecSpecOrScope n -> unsome n.spec_spec_or_scope_spec_module
    | _ -> failwith "bad AST" in
    match m1 with
    | AModSpecModule m' -> fn1 (d m'.mod_spec_module_identifier)
    | AInstSpecModule m' -> fn1 (d m'.inst_spec_module_n)) f

let fetch_spec_module m = 
  match (fetch_spec_module_foo List.find (fun x -> m = x)) with
  | ASpecSpecOrScope m' -> unsome m'.spec_spec_or_scope_spec_module
  | _ -> failwith "got scope, wanted spec"
let fetch_spec_module_names m = 
  fetch_spec_module_foo List.map (fun x -> x)

let fetch_scope_ast n = 
  let l = Util.phase ("Lexing file "^n) 
      Speclanguage.Lexer.create n (open_in n) in
  let p = Speclanguage.Parser.create l in
  Util.phase "Parsing" Speclanguage.Parser.parse p

let parse_scope_asts source_names =
  let frags_so_far = ref [] in
  List.iter (function n ->
    Util.phase ("scope " ^ n)
      ignore (let ast_fragment = fetch_scope_ast n in
      (match ast_fragment with 
        Start (PFile (ASpecOrScopeFile af), _) ->
          frags_so_far := List.concat 
              (List.map 
                 (fun x ->
                   match x with
                   | AScopeSpecOrScope x1 -> 
                       let AScopeDecl c = unsome (x1.scope_spec_or_scope_scope_decl) in
                         Hashtbl.add Ast.scope_to_fn
                                 (d c.scope_decl_name) n;
                         [P (PScopeDecl (AScopeDecl c))]
                   | ASpecSpecOrScope _ -> [])
                   af.spec_or_scope_file_spec_or_scope) @ 
            !frags_so_far
      | _ -> failwith "bad AST");
      ast_fragment)) 
    source_names;
  P (PFile (ASpecOrScopeFile 
              (a_spec_or_scope_file (List.map (fun x -> P (PSpecOrScope (AScopeSpecOrScope (a_scope_spec_or_scope x)))) !frags_so_far))))

let fetch_scope_decl_foo fn fn1 = 
  let f = match !scope_ast with
    P (PFile (ASpecOrScopeFile n)) -> n.spec_or_scope_file_spec_or_scope
  | _ -> failwith "bad AST" in
  fn (fun m0 ->
    let m1 = match m0 with
      AScopeSpecOrScope n -> unsome n.scope_spec_or_scope_scope_decl
    | _ -> failwith "bad AST" in
    match m1 with
    | AScopeDecl m' -> fn1 (d m'.scope_decl_name)) f

let fetch_scope m = 
  match (fetch_scope_decl_foo List.find (fun x -> x = m)) with
  | AScopeSpecOrScope m' -> unsome m'.scope_spec_or_scope_scope_decl
  | _ -> failwith "got spec, wanted scope"
let fetch_scope_names m = fetch_scope_decl_foo List.map (fun x -> x)


open Abstlanguage
open Nodes

(* Note that this is different from the other d. *)
let d x = Tokens.getText (unsome x)

let fetch_abst_ast n = 
  let l = Util.phase ("Lexing file "^n) 
      Abstlanguage.Lexer.create n (open_in n) in
  let p = Abstlanguage.Parser.create l in
  Util.phase "Parsing" Abstlanguage.Parser.parse p

let parse_abst_asts source_names =
  let name2frag = Hashtbl.create 1 in
  let frags_so_far = ref [] in
  List.iter (function n -> 
    Util.phase ("module " ^ n)
      (Hashtbl.add name2frag n 
         (let ast_fragment = fetch_abst_ast n in
         (match ast_fragment with 
           Start (PFile (AFile af), _) ->
             frags_so_far := (List.map (fun x -> P (PAbstModule x)) 
                                af.file_abst_module) @ 
          !frags_so_far
         | _ -> failwith "bad AST");
         ast_fragment))) 
            source_names;
  (name2frag, P (PFile (AFile (Nodes.a_file !frags_so_far))))

let fetch_abst_module m =
  let f = match !abst_ast with
    P (PFile (AFile n)) -> n.file_abst_module
  | _ -> failwith "bad AST" in
  List.find (fun m0 -> match m0 with
  | AAbstModule m' -> m = d m'.abst_module_abst_module_name
  | AInstAbstModule m' -> m = d m'.inst_abst_module_n) f

let fetch_abst_module_names m =
  let f = match !abst_ast with
    P (PFile (AFile n)) -> n.file_abst_module
  | _ -> failwith "bad AST" in
  List.map (fun m0 -> match m0 with
  | AAbstModule m' -> d m'.abst_module_abst_module_name
  | AInstAbstModule m' -> d m'.inst_abst_module_n) f

open Formatlanguage
open Nodes

let d x = Tokens.getText (unsome x)


(* I can't figure out how to make CST -> AST transformations in SableCC
   generate AFieldAccessExpr instead of AQualifiedNameExpr, 
   so transform here. *)
let rec convert_qualified_to_field_expr x =
  (AFieldAccessExpr (Nodes.a_field_access_expr 
                       (match unsome x.qualified_name_expr_m with
                       | ASimpleNameExpr m -> 
                           (P (PExpr (ASimpleNameExpr m)))
                       | AFieldAccessExpr m ->
                           (P (PExpr (AFieldAccessExpr m)))
                       | AQualifiedNameExpr m -> 
                           (P (PExpr (convert_qualified_to_field_expr m)))
                       | _ -> failwith "badly formed qualified name expr")
                       (T (unsome x.qualified_name_expr_n)))) 

let rec qualified_to_field_transformer = {
  Analysis.override = (fun parent n -> n);
     Analysis.enter = (fun parent n -> match (parent, n) with
     | (P (PExpr (AInvokeExpr i)), P (PExpr e)) 
       when i.invoke_expr_expr = (Some e) -> 
         Analysis.dummy_visitor
     | _ -> qualified_to_field_transformer);
     Analysis.leave = (fun parent old_child child v -> 
       match child with
     | P (PExpr (AQualifiedNameExpr m)) -> 
         P (PExpr (convert_qualified_to_field_expr m))
     | _ -> child);
     Analysis.start = (fun () -> qualified_to_field_transformer);
    Analysis.finish = (fun n -> ());
}

let fetch_impl_ast n = 
  let l = Util.phase ("Lexing file "^n) Lexer.create n (open_in n) in
  let p = Parser.create l in
  let pt = Util.phase "Parsing" Parser.parse p in
  (Analysis.visit_edge qualified_to_field_transformer
     Nodes.Null_Node pt)

let parse_impl_asts source_names =
  (* Engage in some wizardry to put all ASTs together. *)
  let frags_so_far = ref [] in
  List.iter (function n -> 
    Util.phase ("module " ^ n)
      ignore (let ast_fragment0 = fetch_impl_ast n in
      let ast_fragment = Analysis.visit_edge 
          qualified_to_field_transformer
          Nodes.Null_Node ast_fragment0 in
      (match ast_fragment with 
        Start (PFile (AFile af), _) ->
          frags_so_far := (List.map (fun x -> 
            let x' = P (PImplModule x) in
            Hashtbl.add impl_to_fn x' n;
            x') af.file_impl_module) @ !frags_so_far
      | _ -> failwith "bad AST");
      ast_fragment))
    source_names;
  P (PFile (AFile (Nodes.a_file !frags_so_far)))

let fetch_impl_module m =
  let f = match !impl_ast with
    P (PFile (AFile n)) -> n.file_impl_module
  | _ -> failwith "bad AST" in
  List.find (fun m0 ->
    match m0 with
    | AModuleImplModule m' -> 
        m = d m'.module_impl_module_identifier 
    | AInstImplModule m' ->
        m = d m'.inst_impl_module_n) f

let fetch_impl_module_names m =
  let f = match !impl_ast with
    P (PFile (AFile n)) -> n.file_impl_module
  | _ -> failwith "bad AST" in
  List.map (fun m0 ->
    match m0 with
    | AModuleImplModule m' -> d m'.module_impl_module_identifier
    | AInstImplModule m' -> d m'.inst_impl_module_n) f
