(* things that need IDs: 
 * formats          (globally unique)
 * modules          (globally unique)
 * fields           (per-module/format namespace)
 * procs            (per-module namespace)
 * references       (per-module namespace)
 * local variables  (per-block namespace)
 *)

type scope_t = string

type format_t = string 
type module_t = string
type field_t = { f_name:string; f_module:module_t }
type proc_t = { p_name:string; p_module:module_t; }
type default_t = { d_name:string; d_module:module_t; }
type var_t = string

let fetch_scope : string -> scope_t = function s -> s
let fetch_format : string -> format_t = function s -> s
let fetch_module : string -> module_t = function s -> s
let fetch_field (m:module_t) (n:string) : field_t = 
  { f_name = n; f_module = m }
let fetch_proc (m:module_t) (n:string) : proc_t = 
  { p_name = n; p_module = m; }
let fetch_default (m:module_t) (n:string) : default_t = 
  { d_name = n; d_module = m; }
let fetch_var : string -> var_t = function s -> s

let name_of_field f = f.f_name
let module_of_field f = f.f_module

let name_of_proc p = p.p_name
let module_of_proc p = p.p_module
let qualified_name_of_proc p = p.p_module ^ "." ^ p.p_name

let name_of_default d = d.d_name
let module_of_default d = d.d_module

let main_module = fetch_module "Main"
let unknown_format = fetch_format "Unknown"
let null_format = fetch_format "Null"

type modifiers_t = {
    is_private : bool;
  }
