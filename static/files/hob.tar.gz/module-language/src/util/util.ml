(* openqualified List, String, Str *)

exception Bad_string
exception Bail

(* Qualify helper file name *)
(* if you want to install the executable in one directory (e.g. /usr/bin),
 * but put helper files in another (/usr/share/module-language),
   here's what you need to change! *)

let qualify_helper_fn n =
  let d = Filename.dirname Sys.executable_name ^ "/" in
  d ^ n

(* List-handling stuff *)
let rec remove_dups n = 
  match n with
    [] -> []
  | q::qs -> if (List.mem q qs) then remove_dups qs else q::(remove_dups qs)

let rec find_dups n = 
  match n with
    [] -> []
  | q::qs -> if (List.mem q qs) then q::(find_dups qs) else find_dups qs


let disjoint l1 l2 = 
  List.for_all (fun x -> not (List.mem x l2)) l1

let intersect l1 l2 =
  List.filter (fun x -> List.mem x l2) l1

let intersect_list l =
  match l with
  | [] -> []
  | hd::[] -> hd
  | hd::tl -> List.fold_left intersect hd tl

let difference l1 l2 =
  List.filter (fun x -> not (List.mem x l2)) l1

let spacify i = 
  let s' z = List.fold_left (fun x y -> x ^ i ^ y) "" z in
  function [] -> ""
  | [x] -> x
  | x::xs -> x ^ (s' xs)

(* String-handling stuff *)
let trim_quotes s = 
  let trim_last s' = if String.get s' ((String.length s')-1) = '"' then
    String.sub s' 0 ((String.length s')-1) else s' in
  if String.get s 0 = '"' then 
    (trim_last (String.sub s 1 ((String.length s) - 1)))
  else
    trim_last s

let unescaped s =
  let n = ref 0 in
    for i = 0 to String.length s - 1 do
      n := !n +
        (match String.unsafe_get s i with
           '\\' when String.unsafe_get s (i+1) != '\\' ->
             (match String.unsafe_get s (i+1) with
               'n' -> 0
             | 't' -> 0
             | '"' -> 0
             | _ -> 1)
        | _ -> 1)
    done;
    if !n = String.length s then s else begin
      let s' = String.create !n in
      n := 0;
      let skip = ref 0 in
      (try (for i = 0 to String.length s - 1 do
        begin
          if (i + !skip) = String.length s then raise Bail;
          match String.unsafe_get s (i + !skip) with
          | '\\' when String.unsafe_get s (i+ !skip+1) != '\\' ->
              (match String.unsafe_get s (i+ !skip+1) with
                'n' -> String.unsafe_set s' !n '\n'; incr skip
              | 'r' -> String.unsafe_set s' !n '\r'; incr skip
              | 't' -> String.unsafe_set s' !n '\t'; incr skip
              | '"' -> String.unsafe_set s' !n '\"'; incr skip
              | '\\' -> String.unsafe_set s' !n '\\'; incr skip;
              | _ -> raise Bad_string)
          | c -> String.unsafe_set s' !n c
        end;
        incr n
      done) with Bail -> ());
      Str.first_chars s' (String.length s - !skip)
    end

let replace_dot_with_uscore s =
  let dot = Str.regexp "\\." in
  let caret = Str.regexp "\\^" in
  Str.global_replace dot "_" 
    (Str.global_replace caret "$" s)

let split_by sep s =
  let sep_regexp = Str.regexp (Str.quote sep) in
  Str.split sep_regexp s

(* Error-handling stuff *)
let error_list = ref []

let err loc msg = 
  error_list := !error_list @
    [loc ^ ": error: "^msg]

let error msg = (prerr_string (msg ^"\n"); flush_all(); err "" msg)
let warn msg = (prerr_string ("Warning: "^ msg ^"\n"); flush_all())

let no_errors () = (List.length !error_list = 0)

let print_errors () = 
  List.iter (function x -> prerr_string (x ^ "\n")) !error_list;
  prerr_string (string_of_int (List.length !error_list)^" errors.\n");
  prerr_string "The program is INVALID\n";
  exit 2

let fatal msg = flush_all(); 
  prerr_string ("Fatal error: "^msg^"\n"); print_errors ()

(* Printing notifications [msg, amsg, etc] *)
let verbose = ref false

(* always print this message *)
let amsg s = prerr_string s; flush_all ()

(* print only if -v *)
let msg s = if !verbose then amsg s
  
let phase : string -> 'a -> 'a =
  function s -> function v -> 
    msg s; msg "..."; 
    let r = v in msg "done.\n"; r

(* filename handling; returns the inverse of Filename.chop_extension *)
let extension n =
  let d = String.rindex n '.' in
  String.sub n d (String.length n - d)

(* removing 'option' types *)
let unsome : 'a option -> 'a = 
function
  | Some x -> x
  | None   -> failwith "[util] tried to deoptionify None"

(* slurp the given file *)
let fileToLine (fn:string) : string =
  begin
    let chn = open_in fn in
      let str = input_line chn in
      close_in chn;
      str
  end

let empty l = match l with [] -> true | _ -> false

(* namespace mangling stuff *)
let qualify_if_needed mname n =
  if String.contains n '.' then n else (mname ^ "." ^ n)

let unqualify_getting_module s =
  if String.contains s '.' then
    let i = String.rindex s '.' in
    String.sub s 0 i
  else ""

let unqualify s =
  if String.contains s '.' then
    let i = String.rindex s '.' in
    String.sub s (i+1) (String.length s - i - 1)
  else s

let unprime s =
  let l = String.length s in 
  if l = 0 then s else 
  if (String.get s (l-1)) = '\'' then
    String.sub s 0 (l-1) else s

let is_primed s =
  let l = String.length s in 
  if l = 0 then false else 
  (String.get s (l-1) = '\'')


(* let run_with_timeout f arg seconds = f arg *)

(*
let (run_function_with_timeout : ('a -> int) -> 'a -> int -> int) = 
fun f arg seconds ->
  let pid = Unix.fork() in
  if pid = 0 then
    (* child *)
    (ignore (Unix.alarm seconds); f arg)
  else
    (* parent *)
    let (exitcode,pid1) = Unix.wait() in exitcode

let (run_with_timeout : string -> int -> int) = 
fun prog seconds ->
  let pid = Unix.fork() in
  if pid = 0 then
    (* child *)
    (ignore (Unix.alarm seconds);      
     Unix.execv "/bin/sh" [|"-c" ^ prog|])
  else
    (* parent *)
    let (exitcode,pid1) = Unix.wait() in exitcode
*)

let get_path s = 
  if String.contains s '/' then
    let i = String.rindex s '/' in
    String.sub s 0 (i+1)
  else ""

let timed_command = qualify_helper_fn "timed_command"

let (run_with_timeout : string -> int -> int) = 
fun prog seconds ->  
  Sys.command (timed_command ^ Printf.sprintf " %d " seconds ^ prog)
