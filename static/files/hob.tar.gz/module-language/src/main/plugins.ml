let analyze_module f 
    (mn:string)
    ((ma:string Aabsyn.abst_body),
     (ms:Sabsyn.spec_module),
     (mi0:string Iabsyn.impl_module)) 
    (pn:string list)
    (rs:Iabsyn.expr list) aug : bool =
  let mi = Util.phase "Pulling up locals" Itrans.pull_up_locals mi0 in
  Util.phase "Recomputing types" Typechecker.verify [mi];
  f mn (ma,ms,mi) pn

let analyze_typestate_module
    (mn:string)
    ((ma:string Aabsyn.abst_body),
     (ms:Sabsyn.spec_module),
     (mi0:string Iabsyn.impl_module)) 
    (pn:string list)
    (rs:Iabsyn.expr list) 
    (aug:Id.proc_t -> Sabsyn.form -> bool -> Sabsyn.form) : bool = 
  let mi1 = Util.phase "Jimplifying" Itrans.jimplify mi0 in
  let mi = Util.phase "Pulling up locals" Itrans.pull_up_locals mi1 in
  Util.phase "Recomputing jimplified types" Typechecker.verify [mi];
  Typestate.analyze_module mn (ma,ms,mi) pn rs aug

let find_neutral_procs plugin =
  match plugin with
  | "flags" -> Typestate.neutral_procs
  | "PALE" -> Pale.neutral_procs
  | "vcgen" -> Vcgen.neutral_procs
  | "Bohne" -> Bohne.Bohne.neutral_procs
  | "Bohne decaf" -> Bohne.Bohne.neutral_procs
  | s -> failwith ("Couldn't understand plugin " ^ s ^ ".\n")

let dispatch_plugin plugin = 
  match plugin with
  | "flags" -> analyze_typestate_module
  | "PALE" -> analyze_module Pale.analyze_module
  | "vcgen" -> analyze_module Vcgen.analyze_module
  | "Bohne" -> analyze_module Bohne.Bohne.analyze_module 
  | "Bohne decaf" -> Bohne.Bohne.enable_vc_mode (); analyze_module Bohne.Bohne.analyze_module 
  | s -> failwith ("Couldn't understand plugin " ^ s ^ ".\n")
