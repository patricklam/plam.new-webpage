open Iabsyn
open Types
open Id

exception Intrinsic_return of value option

let rec make_pairs : value list -> (value * string) list =
  fun args -> match args with
  | [] -> []
  | (Obj i)::(String s)::rest -> (Obj i, s) :: make_pairs rest
  | _ -> failwith "wrong arguments to heap_dump"

let last_event : Graphics.status option ref = ref None
let saw_eof = ref false
let errno = ref 0l

let convert_errno e =
  match e with
  | Unix.EACCES -> 13l
  | Unix.ENOTDIR -> 20l
  | Unix.ELOOP -> 40l
  | _ -> 0l

let set_errno e =
  errno := convert_errno e

let flag_alist = 
  [(Unix.O_RDONLY, 1); (Unix.O_WRONLY, 2);
   (Unix.O_RDWR, 4); (Unix.O_NONBLOCK, 8);
   (Unix.O_APPEND, 16); (Unix.O_CREAT, 32);
   (Unix.O_TRUNC, 64); (Unix.O_EXCL, 128);
   (Unix.O_NOCTTY, 256); (Unix.O_DSYNC, 512);
   (Unix.O_SYNC, 1024); (Unix.O_RSYNC, 2048)]

let file_kind_of_int i =
  match i with
  | 1 -> Unix.S_REG
  | 2 -> Unix.S_DIR
  | 3 -> Unix.S_CHR
  | 4 -> Unix.S_BLK
  | 5 -> Unix.S_LNK
  | 6 -> Unix.S_FIFO
  | 7 -> Unix.S_SOCK
  | _ -> failwith "not a file kind"

let int_of_file_kind fk =
  match fk with
  | Unix.S_REG -> 1l
  | Unix.S_DIR -> 2l
  | Unix.S_CHR -> 3l
  | Unix.S_BLK -> 4l
  | Unix.S_LNK -> 5l
  | Unix.S_FIFO -> 6l
  | Unix.S_SOCK -> 7l

let attach_stat_fields hobj st =
  Intrheap.set_field hobj 
    (fetch_field "System" "st_dev") (Int (Int32.of_int st.Unix.st_dev));
  Intrheap.set_field hobj 
    (fetch_field "System" "st_ino") (Int (Int32.of_int st.Unix.st_ino));
  Intrheap.set_field hobj 
    (fetch_field "System" "st_kind") (Int (int_of_file_kind st.Unix.st_kind));
  Intrheap.set_field hobj
    (fetch_field "System" "st_perm") (Int (Int32.of_int st.Unix.st_perm)); 
  Intrheap.set_field hobj
    (fetch_field "System" "st_nlink") (Int (Int32.of_int st.Unix.st_nlink));
  Intrheap.set_field hobj
    (fetch_field "System" "st_uid") (Int (Int32.of_int st.Unix.st_uid));
  Intrheap.set_field hobj
    (fetch_field "System" "st_gid") (Int (Int32.of_int st.Unix.st_gid));
  Intrheap.set_field hobj
    (fetch_field "System" "st_rdev") (Int (Int32.of_int st.Unix.st_rdev));
  Intrheap.set_field hobj
    (fetch_field "System" "st_size") (Int (Int32.of_int st.Unix.st_size));
  Intrheap.set_field hobj
    (fetch_field "System" "st_atime") (Float st.Unix.st_atime);
  Intrheap.set_field hobj
    (fetch_field "System" "st_mtime") (Float st.Unix.st_mtime);
  Intrheap.set_field hobj
    (fetch_field "System" "st_ctime") (Float st.Unix.st_ctime)

(*let attach_time_fields hobj tm =
  Intrheap.set_field hobj 
    (fetch_field "System" "tm_sec") (Int tm.Unix.tm_sec);
  Intrheap.set_field hobj 
    (fetch_field "System" "tm_min") (Int tm.Unix.tm_min);
  Intrheap.set_field hobj 
    (fetch_field "System" "tm_hour") (Int tm.Unix.tm_hour);
  Intrheap.set_field hobj
    (fetch_field "System" "tm_mday") (Int tm.Unix.tm_mday); 
  Intrheap.set_field hobj
    (fetch_field "System" "tm_mon") (Int tm.Unix.tm_mon);
  Intrheap.set_field hobj
    (fetch_field "System" "tm_year") (Int tm.Unix.tm_year);
  Intrheap.set_field hobj
    (fetch_field "System" "tm_wday") (Int tm.Unix.tm_wday);
  Intrheap.set_field hobj
    (fetch_field "System" "tm_yday") (Int tm.Unix.tm_yday);
  Intrheap.set_field hobj
    (fetch_field "System" "tm_isdst") (Int tm.Unix.tm_isdst)*)

let eval_intrinsic (proc:Id.proc_t) (args:value list) : unit =
  let punt () = failwith ("runtime (?!?) type error on "^(module_of_proc proc)^"."^(name_of_proc proc)) in
  if Intrinsics.is_noarg_intrinsic proc then
    begin
      if args <> [] then
        punt();
      match ((module_of_proc proc), (name_of_proc proc)) with
      | ("System", "read_int") -> 
          raise (Intrinsic_return (Some (Int (Int32.of_int (read_int ())))))
      | ("System", "read_float") -> 
          raise (Intrinsic_return (Some (Float (read_float ()))))
      | ("System", "errno") ->
          raise (Intrinsic_return (Some (Int (!errno))))
      | ("System", "eof") ->
          raise (Intrinsic_return (Some (Bool !saw_eof)))
      | ("System", "time") ->
          raise (Intrinsic_return (Some (Float (Unix.time ()))))
      | ("System", "O_RDONLY") -> 
          raise (Intrinsic_return (Some (Int 1l)))
      | ("System", "O_WRONLY") ->
          raise (Intrinsic_return (Some (Int 2l)))
      | ("System", "O_RDWR") ->
          raise (Intrinsic_return (Some (Int 4l)))
      | ("System", "O_NONBLOCK") ->
          raise (Intrinsic_return (Some (Int 8l)))
      | ("System", "O_APPEND") ->
          raise (Intrinsic_return (Some (Int 16l)))
      | ("System", "O_CREAT") ->
          raise (Intrinsic_return (Some (Int 32l)))
      | ("System", "O_TRUNC") ->
          raise (Intrinsic_return (Some (Int 64l)))
      | ("System", "O_EXCL") ->
          raise (Intrinsic_return (Some (Int 128l)))
      | ("System", "O_NOCTTY") ->
          raise (Intrinsic_return (Some (Int 256l)))
      | ("System", "O_DSYNC") ->
          raise (Intrinsic_return (Some (Int 512l)))
      | ("System", "O_SYNC") ->
          raise (Intrinsic_return (Some (Int 1024l)))
      | ("System", "O_RSYNC") ->
          raise (Intrinsic_return (Some (Int 2048l)))
      | ("System", "S_REG") -> 
          raise (Intrinsic_return (Some (Int (int_of_file_kind Unix.S_REG))))
      | ("System", "S_DIR") ->
          raise (Intrinsic_return (Some (Int (int_of_file_kind Unix.S_DIR))))
      | ("System", "S_CHR") ->
          raise (Intrinsic_return (Some (Int (int_of_file_kind Unix.S_CHR))))
      | ("System", "S_BLK") ->
          raise (Intrinsic_return (Some (Int (int_of_file_kind Unix.S_BLK))))
      | ("System", "S_LNK") ->
          raise (Intrinsic_return (Some (Int (int_of_file_kind Unix.S_LNK))))
      | ("System", "S_FIFO") ->
          raise (Intrinsic_return (Some (Int (int_of_file_kind Unix.S_FIFO))))
      | ("System", "S_SOCK") ->
          raise (Intrinsic_return (Some (Int (int_of_file_kind Unix.S_SOCK))))
      | ("System", "EACCES") -> 
          raise (Intrinsic_return (Some (Int (convert_errno Unix.EACCES))))
      | ("System", "ENOTDIR") -> 
          raise (Intrinsic_return (Some (Int (convert_errno Unix.ENOTDIR))))
      | ("System", "ELOOP") -> 
          raise (Intrinsic_return (Some (Int (convert_errno Unix.ELOOP))))
      | ("Sockets", "PF_UNIX") -> 
          raise (Intrinsic_return (Some (Int 0l)))
      | ("Sockets", "PF_INET") -> 
          raise (Intrinsic_return (Some (Int 1l)))
      | ("Sockets", "SOCK_STREAM") -> 
          raise (Intrinsic_return (Some (Int 0l)))
      | ("Sockets", "SOCK_DGRAM") -> 
          raise (Intrinsic_return (Some (Int 1l)))
      | ("Sockets", "SOCK_SEQPACKET") -> 
          raise (Intrinsic_return (Some (Int 2l)))
      | ("Sockets", "SOCK_RAW") -> 
          raise (Intrinsic_return (Some (Int 3l)))
      | ("Graphics", "KEY_PRESSED") ->
          raise (Intrinsic_return (Some (Int 0x1l)))
      | ("Graphics", "BUTTON_DOWN") ->
          raise (Intrinsic_return (Some (Int 0x2l)))
      | ("Graphics", "BUTTON_UP") -> 
          raise (Intrinsic_return (Some (Int 0x4l)))
      | ("Graphics", "keypressed") -> 
          (match !last_event with
          | Some st -> 
              raise (Intrinsic_return 
                       (Some (Bool st.Graphics.keypressed)))
          | None -> failwith "keypressed without event")
      | ("Graphics", "last_key_pressed") -> 
          (match !last_event with
          | Some st -> 
              raise (Intrinsic_return 
                       (Some (Char st.Graphics.key)))
          | None -> failwith "last_key_pressed without event")
      | ("Graphics", "last_click_x") -> 
          (match !last_event with
          | Some st -> 
              raise (Intrinsic_return 
                       (Some (Int (Int32.of_int st.Graphics.mouse_x))))
          | None -> failwith "last_click_x without event")
      | ("Graphics", "last_click_y") -> 
          (match !last_event with
          | Some st -> 
              raise (Intrinsic_return 
                       (Some (Int (Int32.of_int st.Graphics.mouse_y))))
          | None -> failwith "last_click_y event")
      | ("Graphics", "current_point_x") -> 
          (match args with
            [] -> 
              raise (Intrinsic_return 
                       (Some (Int (Int32.of_int (fst (Graphics.current_point ()))))))
          | _ -> failwith "type error for current_point_x")
      | ("Graphics", "current_point_y") ->
          (match args with
            [] -> 
              raise (Intrinsic_return 
                       (Some (Int (Int32.of_int (snd (Graphics.current_point ()))))))
          | _ -> failwith "type error for current_point_y")
      | ("Graphics", "close_graph") -> 
          (match args with
            [] -> Graphics.close_graph ()
          | _ -> failwith "type error for close_graph");
          raise (Intrinsic_return None)
      | _ -> failwith ("is_noarg_intrinsic lied to me about "^
                       (module_of_proc proc)^"."^(name_of_proc proc)^"!")
    end;
  if Intrinsics.is_intrinsic proc then
    match ((module_of_proc proc), (name_of_proc proc)) with
      ("System", "print_int") -> 
        List.iter (function (Int x) -> print_string (Int32.to_string x)
          | y -> failwith ("type error on print_int: got "^(string_of_value_type (value_type_of_value y)))) args; 
        raise (Intrinsic_return None)
    | ("System", "float_of_int") ->
        let bd = List.hd args in
        ignore (match bd with
        | Int b -> raise (Intrinsic_return (Some (Float (Int32.to_float b))))
        | _ -> failwith "type error on float_of_int: got "^(string_of_value_type (value_type_of_value bd)));
        raise (Intrinsic_return None)
    | ("System", "string_of_int") ->
        let bd = List.hd args in
        ignore (match bd with
        | Int b -> raise (Intrinsic_return (Some (String (Int32.to_string b))))
        | _ -> failwith "type error on string_of_int: got "^(string_of_value_type (value_type_of_value bd)));
        raise (Intrinsic_return None)
    | ("System", "int_of_string") ->
        let bd = List.hd args in
        ignore (match bd with
        | String b -> raise (Intrinsic_return (Some (Int (Int32.of_string b))))
        | _ -> failwith "type error on int_of_string: got "^(string_of_value_type (value_type_of_value bd)));
        raise (Intrinsic_return None)
    | ("System", "float_of_string") ->
        let bd = List.hd args in
        ignore (match bd with
        | String b -> raise (Intrinsic_return (Some (Float (float_of_string b))))
        | _ -> failwith "type error on float_of_string: got "^(string_of_value_type (value_type_of_value bd)));
        raise (Intrinsic_return None)
    | ("System", "int_of_float") ->
        let bd = List.hd args in
        ignore (match bd with
        | Float b -> raise (Intrinsic_return (Some (Int (Int32.of_float b))))
        | _ -> failwith "type error on int_of_float");
        raise (Intrinsic_return None)
    | ("System", "char_of_int") ->
        let bd = List.hd args in
        ignore (match bd with
        | Int b -> raise (Intrinsic_return (Some (Char (char_of_int (Int32.to_int b)))))
        | _ -> failwith "type error on char_of_int");
        raise (Intrinsic_return None)
    | ("System", "print_float") -> 
        List.iter (function (Float x) -> print_float x 
          | _ -> failwith "type error on print_float") args;
        flush stdout;
        raise (Intrinsic_return None)
    | ("System", "print_string") -> 
        List.iter (function (String x) -> print_string x 
          | _ -> failwith "type error on print_string") args;
        flush stdout;
        raise (Intrinsic_return None)
    | ("System", "output_string") -> 
        (match args with
        | [oc; String s] -> 
            let c = Intrheap.get_output_channel_mapping oc in
            output_string c s;
        | _ -> punt());
        raise (Intrinsic_return None)
    | ("System", "output") -> 
        (match args with
        | [oc; String s; Int ofs; Int len] ->
            let c = Intrheap.get_output_channel_mapping oc in
            output c s (Int32.to_int ofs) (Int32.to_int len);
        | _ -> punt());
        raise (Intrinsic_return None)
    | ("System", "heap_dump") ->          
        (match args with
          String fileName :: String comment :: rest -> begin
            Intrheapdumper.dump fileName comment (make_pairs rest);
            raise (Intrinsic_return None)
          end
        | _ -> failwith "type error on heap_dump args")
    | ("System", "random") ->
        let bd = List.hd args in
        ignore (match bd with
        | Int b -> raise (Intrinsic_return (Some (Int (Int32.of_int (Random.int (Int32.to_int b))))))
        | _ -> failwith "type error on random: got "^(string_of_value_type (value_type_of_value bd)));
        raise (Intrinsic_return None)
    | ("System", "srand") ->
        let bd = List.hd args in
        ignore (match bd with
        | Int b -> Random.init (Int32.to_int b);
            raise (Intrinsic_return None)
        | _ -> failwith "type error on random: got "^(string_of_value_type (value_type_of_value bd)));
        raise (Intrinsic_return None)
    | ("Math", "abs") -> 
        (match args with
          [Float b] -> 
            raise (Intrinsic_return (Some (Float (abs_float b))))
        | _ -> failwith "type error for Math.abs")
    | ("Math", "exp") -> 
        (match args with
          [Float b] -> 
            raise (Intrinsic_return (Some (Float (exp b))))
        | _ -> failwith "type error for Math.exp")
    | ("Math", "pow") -> 
        (match args with
          [Float b; Float e] -> 
            raise (Intrinsic_return (Some (Float (b**e))))
        | _ -> failwith "type error for Math.pow")
    | ("Math", "sqrt") -> 
        (match args with
          [Float f] -> 
            raise (Intrinsic_return (Some (Float (sqrt f))))
        | _ -> failwith "type error for Math.sqrt")
    | ("Math", "sin") -> 
        (match args with
          [Float f] -> 
            raise (Intrinsic_return (Some (Float (sin f))))
        | _ -> failwith "type error for Math.sin")
    | ("Math", "cos") -> 
        (match args with
          [Float f] -> 
            raise (Intrinsic_return (Some (Float (cos f))))
        | _ -> failwith "type error for Math.cos")
    | ("Math", "acos") -> 
        (match args with
          [Float f] -> 
            raise (Intrinsic_return (Some (Float (acos f))))
        | _ -> failwith "type error for Math.acos")
    | ("System", "open_in") ->
        let bd = List.hd args in
        ignore (match bd with
        | String x -> 
            saw_eof := false; 
            let fd = open_in x in
            let nobj = Intrheap.fresh_obj () in
            Intrheap.put_input_channel_mapping nobj fd;
            raise (Intrinsic_return (Some nobj))
        | _ -> punt())
    | ("System", "in_channel_of_file_descr") ->
        (match args with
        | [fo] -> 
            saw_eof := false; 
            let nobj = Intrheap.fresh_obj () in
            let fd = Intrheap.get_file_descr_mapping fo in
            let ic = Unix.in_channel_of_descr fd in
            Intrheap.put_input_channel_mapping nobj ic;
            raise (Intrinsic_return (Some nobj))
        | _ -> punt())
    | ("System", "out_channel_of_file_descr") ->
        (match args with
        | [fo] -> 
            saw_eof := false; 
            let nobj = Intrheap.fresh_obj () in
            let fd = Intrheap.get_file_descr_mapping fo in
            let oc = Unix.out_channel_of_descr fd in
            Intrheap.put_output_channel_mapping nobj oc;
            raise (Intrinsic_return (Some nobj))
        | _ -> punt())
    | ("System", "input_line") ->
        let bd = List.hd args in
        ignore (match bd with
        | Obj _ -> 
            saw_eof := false; 
            let fd = Intrheap.get_input_channel_mapping bd in
            let s = try input_line fd with
            | End_of_file -> saw_eof := true; "" in
            raise (Intrinsic_return (Some (String s)))
        | _ -> failwith "type error on input_line")
    | ("System", "close_in") ->
        let bd = List.hd args in
        ignore (match bd with
        | Obj n -> 
            saw_eof := false; 
            let fd = Intrheap.get_input_channel_mapping bd in
            close_in fd;
            Intrheap.clear_input_channel_mapping bd;
            raise (Intrinsic_return None)
        | _ -> failwith "type error on close_in")
    | ("System", "close_out") ->
        let bd = List.hd args in
        ignore (match bd with
        | Obj n -> 
            saw_eof := false; 
            let fd = Intrheap.get_output_channel_mapping bd in
            close_out fd;
            Intrheap.clear_output_channel_mapping bd;
            raise (Intrinsic_return None)
        | _ -> failwith "type error on close_out")
    | ("System", "flush") ->
        let bd = List.hd args in
        ignore (match bd with
        | Obj n -> 
            saw_eof := false; 
            let fd = Intrheap.get_output_channel_mapping bd in
            flush fd;
            raise (Intrinsic_return None)
        | _ -> failwith "type error on flush")
    | ("System", "exit") ->
        (match args with
          [Int i] -> exit (Int32.to_int i)
        | _ -> failwith "type error for exit")
    | ("System", "hash_code") ->
        (match args with
          [Obj i] -> raise (Intrinsic_return (Some (Int (Int32.of_int i))))
        | _ -> failwith "type error for hash_code")
    | ("String", "get") -> 
        (match args with
          [String s; Int i] -> raise (Intrinsic_return (Some (Char (s.[(Int32.to_int i)]))))
        | _ -> failwith "type error for String.get")
    | ("String", "string_after") -> 
        (match args with
          [String s; Int i] -> 
            raise (Intrinsic_return (Some (String (Str.string_after s (Int32.to_int i)))))
        | _ -> failwith "type error for String.string_after")
    | ("String", "string_before") -> 
        (match args with
          [String s; Int i] -> 
            raise (Intrinsic_return (Some (String (Str.string_before s (Int32.to_int i)))))
        | _ -> failwith "type error for String.string_before")
    | ("String", "index") -> 
        (match args with
          [String s; Char c] -> 
            raise (Intrinsic_return (Some (Int 
               (try (Int32.of_int (String.index s c)) with Not_found -> -1l))))
        | _ -> failwith "type error for String.index")
    | ("String", "contains") -> 
        (match args with
          [String s; Char c] -> 
            raise (Intrinsic_return (Some (Bool (String.contains s c))))
        | _ -> failwith "type error for String.contains")
    | ("String", "length") -> 
        (match args with
          [String s] -> 
            raise (Intrinsic_return (Some (Int (Int32.of_int (String.length s)))))
        | _ -> failwith "type error for String.length")
    | ("String", "make") ->
        (match args with
          [Int n; Char c] ->
            raise (Intrinsic_return (Some (String (String.make (Int32.to_int n) c))))
        | _ -> failwith "type error for String.make")
    | ("Sockets", "socket") -> 
        (match args with 
        | [Int domain; Int socket_type; Int protocol] ->
            let d = match domain with 
              0l -> Unix.PF_UNIX | 1l -> Unix.PF_INET 
            | _ -> failwith "bad domain" in
            let st = match socket_type with
              0l -> Unix.SOCK_STREAM | 1l -> Unix.SOCK_DGRAM 
            | 2l -> Unix.SOCK_SEQPACKET | 3l -> Unix.SOCK_RAW 
            | _ -> failwith "bad socket_type" in
            let nobj = Intrheap.fresh_obj () in
            let fd = Unix.socket d st (Int32.to_int protocol) in
            Intrheap.put_file_descr_mapping nobj fd;
            raise (Intrinsic_return (Some nobj))
        | _ -> punt())
    | ("Sockets", "bind") -> (* not the full bind functionality *)
        (match args with 
        | [fdh; Int port] ->
            let fd = Intrheap.get_file_descr_mapping fdh in
            Unix.bind fd 
              (Unix.ADDR_INET
                 ((Unix.gethostbyname (Unix.gethostname())).Unix.h_addr_list.(0), 
                  (Int32.to_int port)));
            raise (Intrinsic_return None)
        | _ -> punt())
    | ("Sockets", "listen") -> 
        (match args with 
        | [fdh; Int maxc] ->
            let fd = Intrheap.get_file_descr_mapping fdh in
            Unix.listen fd (Int32.to_int maxc);
            raise (Intrinsic_return None)
        | _ -> punt())
    | ("Sockets", "accept") -> (* can't get sockaddr from this *)
        (match args with 
        | [fdh] ->
            let fd = Intrheap.get_file_descr_mapping fdh in
            let (s, a) = Unix.accept fd in
            let so = Intrheap.fresh_obj () in
            Intrheap.put_file_descr_mapping so s;
            Intrheap.put_socket_addr_mapping so a;
            raise (Intrinsic_return (Some so))
        | _ -> punt())
    | ("Sockets", "string_of_inet_addr_of_socket") -> 
        (match args with
        | [so] -> 
            let a = Intrheap.get_socket_addr_mapping so in
            (match a with
            | Unix.ADDR_UNIX u -> 
                raise (Intrinsic_return 
                         (Some (String ("unix "^u))))
            | Unix.ADDR_INET (ia, p) -> 
                raise (Intrinsic_return 
                         (Some (String (Unix.string_of_inet_addr ia)))))
        | _ -> punt())
    | ("System", "read") ->
        (match args with
        | [fdh; String buff; Int ofs; Int len] -> 
            let fd = Intrheap.get_file_descr_mapping fdh in
            let b = Unix.read fd buff (Int32.to_int ofs) (Int32.to_int len) in
            raise (Intrinsic_return (Some (Int (Int32.of_int b))))
        | _ -> punt())
    | ("System", "write") ->
        (match args with
        | [fdh; String buff; Int ofs; Int len] -> 
            let fd = Intrheap.get_file_descr_mapping fdh in
            let b = Unix.write fd buff (Int32.to_int ofs) (Int32.to_int len) in
            raise (Intrinsic_return (Some (Int (Int32.of_int b))))
        | _ -> punt())
    | ("System", "openfile") ->
        (match args with 
        | [String fname; Int flags; Int perm] ->
            let f0 = Int32.to_int flags in
            let fl = List.concat 
                (List.map 
                   (fun (x,y) -> if ((y land f0) <> 0) then [x] else [])
                   flag_alist) in
            let so = 
              try 
                let fd = Unix.openfile fname fl (Int32.to_int perm) in
                let so0 = Intrheap.fresh_obj () in
                Intrheap.put_file_descr_mapping so0 fd;
                so0
              with Unix.Unix_error (e, _, _) -> 
                set_errno e; (Obj 0) in
            raise (Intrinsic_return (Some so))
        | _ -> punt())
    | ("System", "fstat") ->
        (match args with
        | [fdh] ->
            let fd = Intrheap.get_file_descr_mapping fdh in
            let fst = Unix.fstat fd in
            let so = Intrheap.fresh_obj() in
            attach_stat_fields so fst;
            raise (Intrinsic_return (Some so))
        | _ -> punt())
    | ("System", "st_kind") ->
        (match args with
        | [so] ->
            let k = Intrheap.get_field so 
                (fetch_field "System" "st_kind") in
            raise (Intrinsic_return (Some k))
        | _ -> punt())
    | ("System", "st_size") ->
        (match args with
        | [so] ->
            let k = Intrheap.get_field so 
                (fetch_field "System" "st_size") in
            raise (Intrinsic_return (Some k))
        | _ -> punt())
    | ("System", "st_mtime") ->
        (match args with
        | [so] ->
            let k = Intrheap.get_field so 
                (fetch_field "System" "st_mtime") in
            raise (Intrinsic_return (Some k))
        | _ -> punt())
    | ("System", "close") ->
        (match args with 
        | [fdh] ->
            let fd = Intrheap.get_file_descr_mapping fdh in
            Unix.close fd;
            Intrheap.clear_file_descr_mapping fdh;
            Intrheap.clear_socket_addr_mapping fdh;
            raise (Intrinsic_return None)
        | _ -> punt())
    | ("System", "mime_time") ->
        (match args with
        | [Float f] ->
            let ftm = Unix.gmtime f in
            let dayName i = 
              match i with 
              | 0 -> "Sun" | 1 -> "Mon" | 2 -> "Tue" | 3 -> "Wed"
              | 4 -> "Thu" | 5 -> "Fri" | 6 -> "Sat" 
              | _ -> failwith "bad day" in
            let monthName i =
              match i with
              | 0 -> "Jan" | 1 -> "Feb" | 2 -> "Mar" | 3 -> "Apr"
              | 4 -> "May" | 5 -> "Jun" | 6 -> "Jul" | 7 -> "Aug"
              | 8 -> "Sep" | 9 -> "Oct" | 10 -> "Nov" | 11 -> "Dec" 
              | _ -> failwith "bad month" in
            let s = Printf.sprintf "%s, %02i %s %04i %02i:%02i:%02i GMT"
                (dayName ftm.Unix.tm_wday) ftm.Unix.tm_mday
                (monthName ftm.Unix.tm_mon) (ftm.Unix.tm_year + 1900)
                ftm.Unix.tm_hour ftm.Unix.tm_min ftm.Unix.tm_sec in
            raise (Intrinsic_return (Some (String s)))
        | _ -> punt())
    | ("Graphics", "open_graph") -> 
        (match args with
          [String d] -> Graphics.open_graph d
        | _ -> failwith "type error for open_graph");
        raise (Intrinsic_return None)
    | ("Graphics", "colour") -> 
        raise (Intrinsic_return 
                 (Some (Int (Int32.of_int
                          (match (List.hd args) with
                          | String s -> (match s with
                            | "black" -> Graphics.black
                            | "white" -> Graphics.white
                            | "red" -> Graphics.red
                            | "green" -> Graphics.green
                            | "blue" -> Graphics.blue
                            | "yellow" -> Graphics.yellow
                            | "cyan" -> Graphics.cyan
                            | "magenta" -> Graphics.magenta
                            | _ -> failwith ("bad colour "^s))
                          | _ -> failwith "type error for colour")))))
    | ("Graphics", "set_colour") -> 
        (match args with
          [Int i] -> Graphics.set_color (Int32.to_int i)
        | _ -> failwith "type error for set_colour");
        raise (Intrinsic_return None)
    | ("Graphics", "set_line_width") ->
        (match args with
          [Int i] -> Graphics.set_line_width (Int32.to_int i)
        | _ -> failwith "type error for set_line_width");
        raise (Intrinsic_return None)
    | ("Graphics", "moveto") -> 
        (match args with
          [Int x; Int y] -> Graphics.moveto (Int32.to_int x) (Int32.to_int y)
        | _ -> failwith "type error for moveto");
        raise (Intrinsic_return None)
    | ("Graphics", "lineto") -> 
        (match args with
          [Int x; Int y] -> Graphics.lineto (Int32.to_int x) (Int32.to_int y)
        | _ -> failwith "type error for lineto");
        raise (Intrinsic_return None)
    | ("Graphics", "fill_rect") ->
        (match args with
          [Int x; Int y; Int w; Int h] -> Graphics.fill_rect (Int32.to_int x) (Int32.to_int y) (Int32.to_int w) (Int32.to_int h)
        | _ -> failwith "type error for fill_rect");
        raise (Intrinsic_return None)
    | ("Graphics", "fill_poly") ->
        (match args with
          [Array px0; Array py0] -> 
            let unint x = 
              match x with Int x' -> (Int32.to_int x')
              | _ -> failwith "bad type for fill_poly" in
            let (px, py) = (List.map unint (Array.to_list px0), 
                            List.map unint (Array.to_list py0)) in
            let p = List.combine px py in
            Graphics.fill_poly (Array.of_list p)
        | _ -> failwith "type error for fill_poly");
        raise (Intrinsic_return None)
    | ("Graphics", "fill_circle") -> 
        (match args with
          [Int x; Int y; Int r] -> Graphics.fill_circle (Int32.to_int x) (Int32.to_int y) (Int32.to_int r)
        | _ -> failwith "type error for fill_circle");
        raise (Intrinsic_return None)
    | ("Graphics", "text_size_x") -> 
        (match args with
          [String s] -> 
            raise (Intrinsic_return 
                     (Some (Int (Int32.of_int (fst (Graphics.text_size s))))))
        | _ -> failwith "type error for text_size_x")
    | ("Graphics", "text_size_y") ->
        (match args with
          [String s] -> 
            raise (Intrinsic_return 
                     (Some (Int (Int32.of_int (snd (Graphics.text_size s))))))
        | _ -> failwith "type error for text_size_y")
    | ("Graphics", "draw_string") -> 
        (match args with
          [String s] -> Graphics.draw_string s
        | _ -> failwith "type error for draw_string");
        raise (Intrinsic_return None)
    | ("Graphics", "get_image") -> 
        (match args with
          [Int x; Int y; Int dx; Int dy] -> 
            let do_array ar = 
              Array (Array.map (fun x -> Int (Int32.of_int x)) ar) in
            let im = Graphics.get_image (Int32.to_int x) (Int32.to_int y) (Int32.to_int dx) (Int32.to_int dy) in
            let im' = Graphics.dump_image im in
            raise (Intrinsic_return (Some (Array (Array.map do_array im'))))
        | _ -> failwith "type error for get_image")
    | ("Graphics", "draw_image") ->
        (match args with
          [Array ar; Int x; Int y] -> 
            let un_array ar0 = (match ar0 with
            | Array ar ->
                Array.map (fun x ->
                  match x with | Int y -> (Int32.to_int y) | _ -> failwith "huh_di") ar
            | _ -> failwith "huh_di2") in
            let im = Graphics.make_image (Array.map un_array ar) in
            Graphics.draw_image im (Int32.to_int x) (Int32.to_int y);
            raise (Intrinsic_return None)
        | _ -> failwith "type error for draw_image");
        (* input; uses state *)
    | ("Graphics", "wait_next_event") -> 
        (match args with
          [Int t0] -> 
            let t = Int32.to_int t0 in
            let pr = if (t land 0x1 = 0x1) then 
              [Graphics.Key_pressed] else [] in
            let bd = if (t land 0x2 = 0x2) then 
              [Graphics.Button_down] else [] in
            let bu = if (t land 0x4 = 0x4) then
              [Graphics.Button_up] else [] in
            last_event := Some (Graphics.wait_next_event (pr @ bd @ bu));
            raise (Intrinsic_return None)
        | _ -> failwith ("type error on wait_next_event"))
    | _ -> failwith ("undefined intrinsic "^Id.module_of_proc proc ^ 
                     "."^Id.name_of_proc proc^"!")
