open Vclemmas

let _ =
  let _ = Vclemmas.init "vcimpliestest" in
    let (lemma_str, lemma) = List.hd !known_facts in
      print_string ("Matching: " ^ lemma_str ^ "\n");
      known_facts := List.tl !known_facts;
      let matched = List.exists (implied(lemma_str, lemma)) !known_facts in
        if matched then print_string "Match found.\n"
                   else print_string "Match not found.\n"

