(* Parsing module *)

let run_typecheck = ref false
let intermediate_dump = ref false

let parse (source_names : string list) = 
  let format_names = ref [] in
  let spec_names = ref [] in
  let abst_names = ref [] in begin
    List.iter (function n -> 
      (match Util.extension n with 
        ".fl" -> format_names := n :: !format_names
      | ".sl" -> spec_names := n :: !spec_names
      | ".al" -> abst_names := n :: !abst_names
      | _ -> failwith ("unrecognized file extension for file "^n))) 
      source_names;
    Util.phase "Parsing specs "
      (Uglyast.spec_ast := snd (Uglyast.parse_spec_asts !spec_names));
    Util.phase "Parsing abst "
      (Uglyast.abst_ast := snd (Uglyast.parse_abst_asts !abst_names));
    Util.phase "Parsing impl "
      (Uglyast.impl_ast := Uglyast.parse_impl_asts !format_names);
    let spec_module_names = Uglyast.fetch_spec_module_names !Uglyast.spec_ast in
    let abst_module_names = Uglyast.fetch_abst_module_names !Uglyast.abst_ast in
    let impl_module_names = Uglyast.fetch_impl_module_names !Uglyast.impl_ast in
    Ast.impl := Util.phase "Converting impl modules "
      (List.map (fun x -> Deuglifyimpl.convert (Uglyast.fetch_impl_module x)) impl_module_names);
    Ast.spec := Util.phase "Converting spec modules "
      (List.map (fun x -> Deuglifyspec.convert (Uglyast.fetch_spec_module x)) spec_module_names);
    Ast.abst := Util.phase "Converting abst modules "
      (List.map (fun x -> Deuglifyabst.convert (Uglyast.fetch_abst_module x)) abst_module_names);
    if !intermediate_dump then run_typecheck := true;
    if !run_typecheck then begin
      Ast.impl := Util.phase "Instantiating impl templates" 
          (List.map (Itrans.instantiate_templates false)) !Ast.impl;
      Ast.spec := Util.phase "Instantiating spec templates" 
          (List.map Strans.instantiate_templates) !Ast.spec;
      Ast.abst := Util.phase "Instantiating abst templates" 
          (List.map Atrans.instantiate_templates) !Ast.abst;
      let r = Typechecker.declaration_checker false !Ast.impl in
      Ast.impl := Util.phase "Local-ref conversion " 
          (List.map (Itrans.transform_local_to_ref_lvalues r)) !Ast.impl;
      ignore (Util.phase "Typechecking" (Typechecker.verify !Ast.impl));
      Ast.impl := Util.phase "Jimplifying" 
          (List.map Itrans.jimplify) !Ast.impl;
      Ast.impl := Util.phase "Pulling up locals" 
          (List.map Itrans.pull_up_locals) !Ast.impl;
      if !intermediate_dump then begin
        let s f = Filename.chop_extension (Filename.basename f) in
        let int_name = (Util.spacify "_" (List.map s !format_names)) 
          ^ ".jfl" in
        Iabsynprinter.openFile int_name;
        List.iter Iabsynprinter.print !Ast.impl;
        Iabsynprinter.close ()
      end
    end
  end

let parse_cmdline () : string list =
  let speclist = 
    [("-v", Arg.Set Util.verbose, 
      "Verbose; display verbose debugging messages.");
     ("-t", Arg.Set run_typecheck,
      "Typecheck; run the typechecking phase after parsing.");
     ("-i", Arg.Set intermediate_dump,
      "Intermediate representation dump (subsumes -t).")] in
  let source_names = ref [] in
  let usage_msg=("Usage:\n  "^Sys.argv.(0)^" [-v] [-t] [-i] <input filename>\n") in
  Arg.parse speclist (fun x -> source_names := x :: !source_names) usage_msg;
  if List.length !source_names = 0 then 
    begin 
      Arg.usage speclist usage_msg; 
      exit 1 
    end;
  !source_names

let _ = begin
  let names = parse_cmdline () in begin
    parse names;
    if not (Util.no_errors ()) then
      Util.print_errors ()
    else
      print_string "Syntactic checking succeeded.\n"
  end
end
