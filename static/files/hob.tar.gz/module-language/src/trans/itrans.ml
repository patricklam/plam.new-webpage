open Iabsyn
open Types

let transform_local_to_ref_lvalues r ast =
  (* $#&#@$*$@& Exprtbl.copy seems broken here.  Why?! -PL *)
  (*Exprtbl.clear Ast.expr_pos;*)
  let rec transform_lvalue lv = 
    match lv with
    | LocalLvalue v -> if List.memq lv r then RefLvalue v else lv
    | RefLvalue rv -> lv
    | FieldLvalue (e', f) -> FieldLvalue (transform_expr e', f) 
    | ArrayLvalue (e', i) -> ArrayLvalue (transform_expr e', 
                                         transform_expr i) 
  and transform_expr e =
    let e' = real_transform_expr e in
    Exprtbl.replace Ast.expr_pos e' (Ast.lookup_expr_pos e);
    e'
  and real_transform_expr e = 
    let te = transform_expr in
    match e with
    | NewExpr _ | LiteralExpr _ -> e
    | VarExpr lvalue -> VarExpr (transform_lvalue lvalue)
    | NewArrayExpr (t, e', d) -> 
        NewArrayExpr (t, List.map transform_expr e', d)
    | FieldAccessExpr (e', f) ->
        FieldAccessExpr (transform_expr e', f)
    | ArrayAccessExpr (e', i) ->
        ArrayAccessExpr (transform_expr e', transform_expr i)
    | ArrayLengthExpr e' ->
        ArrayLengthExpr (transform_expr e')
    | InvokeExpr (p, args) ->
        let args' = List.map transform_expr args in
        InvokeExpr (p, args')
    | AssignExpr (lhs, e') -> 
        let l' = transform_lvalue lhs in
        AssignExpr (l', transform_expr e')
    | PreIncExpr e' -> PreIncExpr (transform_lvalue e')
    | PostIncExpr e' -> PostIncExpr (transform_lvalue e')
    | PreDecExpr e' -> PreDecExpr (transform_lvalue e')
    | PostDecExpr e' -> PostDecExpr (transform_lvalue e')
    | NegExpr e' -> NegExpr (transform_expr e')
    | NotExpr e' -> NotExpr (transform_expr e')
    | PlusExpr (l, r) -> PlusExpr (te l, te r)
    | MinusExpr (l, r) -> MinusExpr (te l, te r)
    | MultExpr (l, r) -> MultExpr (te l, te r)
    | DivExpr (l, r) -> DivExpr (te l, te r)
    | ModExpr (l, r) -> ModExpr (te l, te r)
    | AndExpr (l, r) -> AndExpr (te l, te r) 
    | OrExpr (l, r) -> OrExpr (te l, te r)
    | EqExpr (l, r) -> EqExpr (te l, te r)
    | NeqExpr (l, r) -> NeqExpr (te l, te r)
    | LtExpr (l, r) -> LtExpr (te l, te r)
    | GtExpr (l, r) -> GtExpr (te l, te r) 
    | LteqExpr (l, r) -> LteqExpr (te l, te r)
    | GteqExpr (l, r) -> GteqExpr (te l, te r)
    | BitAndExpr (l, r) -> BitAndExpr (te l, te r)
    | BitOrExpr (l, r) -> BitOrExpr (te l, te r)
    | BitXorExpr (l, r) -> BitXorExpr (te l, te r)
    | ShiftLeftExpr (l, r) -> ShiftLeftExpr (te l, te r) 
    | SignedShiftRightExpr (l, r) -> SignedShiftRightExpr (te l, te r)
    | UnsignedShiftRightExpr (l, r) -> UnsignedShiftRightExpr (te l, te r) in
  let rec transform_stmt s =
    match s with
    | EmptyStmt | AssertStmt _ | PragmaStmt _ | HavocStmt _
    | AssumeStmt _ | ReturnStmt None -> s
    | CompoundStmt cs -> 
        CompoundStmt (List.map transform_stmt cs) 
    | ChoiceStmt (t, u) ->
        ChoiceStmt (transform_stmt t, transform_stmt u)
    | ExprStmt e -> ExprStmt (transform_expr e)
    | LocalDeclStmt (v, t, e) ->
        LocalDeclStmt (v, t, transform_expr e)
    | ReturnStmt (Some e) -> 
        ReturnStmt (Some (transform_expr e))
    | WhileStmt (i, e, w) -> 
        WhileStmt (i, (transform_expr e), transform_stmt w)
    | IfStmt (e, t, f) -> IfStmt ((transform_expr e), 
                                  transform_stmt t,
                                  transform_stmt f) in
  let transform_proc p = 
    { proc_id = p.proc_id;
      proc_modifiers = p.proc_modifiers;
      formals = p.formals;
      ret_val = p.ret_val;
      requires = p.requires;
      modifies = p.modifies;
      ensures = p.ensures;
      proc_body = transform_stmt p.proc_body } in
  { module_name = ast.module_name;
    instantiated_from = ast.instantiated_from;
    param_subst = ast.param_subst;
    formats = ast.formats;
    references = ast.references;
    procs = List.map transform_proc ast.procs;
  }

let jimplify ast =
  (*Exprtbl.clear Ast.expr_pos;*)
  let extra_stmts = ref [] in
  let ctr = ref 0 in
  let scratch () = 
    let c = !ctr in 
    ctr := !ctr + 1;
    ("_t"^(string_of_int c)) in
  let base_expr e = 
    match e with
    | NewExpr _ | LiteralExpr _ | VarExpr LocalLvalue _ -> true
    | _ -> false in
  let base_lvalue lv =
    match lv with
    | LocalLvalue _ -> true
    | _ -> false in
  let rec jimplify_lvalue lv = 
    match lv with
    | LocalLvalue v -> lv
    | RefLvalue rv -> lv
    | FieldLvalue (e', f) -> FieldLvalue (j e', f) 
    | ArrayLvalue (e', i) -> ArrayLvalue (e', j i)  (* quack: should jimplify e' too, but that causes problems with arrays-as-values *)
  and j e' = 
    if not (base_expr e') then
      let e'' = jimplify_expr e' in
      let s = scratch () in
      extra_stmts := !extra_stmts @ 
          [LocalDeclStmt (s, Exprtbl.find Typechecker.typeof e', e'')];
      VarExpr (LocalLvalue s)
    else e'
  and jimplify_expr e =
    let e' = real_jimplify_expr e in
    Exprtbl.add Ast.expr_pos e' (Ast.lookup_expr_pos e);
    e'
  and real_jimplify_expr e = 
    match e with
    | NewExpr _ | LiteralExpr _ -> e
    | VarExpr lvalue -> VarExpr (jimplify_lvalue lvalue)
    | NewArrayExpr (t, e', d) -> 
        NewArrayExpr (t, List.map j e', d)
    | FieldAccessExpr (e', f) -> FieldAccessExpr (j e', f)
    | ArrayAccessExpr (e', i) -> ArrayAccessExpr (j e', j i)
    | ArrayLengthExpr (e') -> ArrayLengthExpr (j e')
    | InvokeExpr (p, args) ->
        let args' = List.map j args in
        InvokeExpr (p, args')
    | AssignExpr (lhs, e') -> 
        if (not (base_expr e') && not (base_lvalue lhs)) then
          AssignExpr (jimplify_lvalue lhs, j e')
        else 
          AssignExpr (jimplify_lvalue lhs, jimplify_expr e')
    | PreIncExpr e' -> PreIncExpr (jimplify_lvalue e')
    | PostIncExpr e' -> PostIncExpr (jimplify_lvalue e')
    | PreDecExpr e' -> PreDecExpr (jimplify_lvalue e')
    | PostDecExpr e' -> PostDecExpr (jimplify_lvalue e')
    | NegExpr e' -> NegExpr (j e')
    | NotExpr e' -> NotExpr (j e')
    | PlusExpr (l, r) -> PlusExpr (j l, j r)
    | MinusExpr (l, r) -> MinusExpr (j l, j r)
    | MultExpr (l, r) -> MultExpr (j l, j r)
    | DivExpr (l, r) -> DivExpr (j l, j r)
    | ModExpr (l, r) -> ModExpr (j l, j r)
    | AndExpr (l, r) -> 
        let jl = j l in
        (* stupid short-circuit evaluation! *)
        let jr = if not (base_expr r) then
          (* wow, this sucks *)
          let es_temp = !extra_stmts in
          extra_stmts := [];
          let e'' = jimplify_expr r in
          let extra_e''_stmts = !extra_stmts in
          extra_stmts := es_temp;

          let e't = Exprtbl.find Typechecker.typeof r in
          let s = scratch () in
          let lhss = LocalLvalue s in
          (* of course, we punt line number info for the new stuff. *)
          extra_stmts := !extra_stmts @ 
            [LocalDeclStmt (s, e't, Iabsyn.LiteralExpr 
                              (Iabsyn.initial_value e't)); 
             Iabsyn.IfStmt (jl, Iabsyn.CompoundStmt 
                              (extra_e''_stmts @
                            [Iabsyn.ExprStmt 
                              (Iabsyn.AssignExpr (lhss, e''))]), 
                             Iabsyn.EmptyStmt)];
          VarExpr lhss
        else r in
        AndExpr (jl, jr) 
    | OrExpr (l, r) -> OrExpr (j l, j r)
    | EqExpr (l, r) -> EqExpr ((*sleazy hack: j*) l, j r)
    | NeqExpr (l, r) -> NeqExpr (j l, j r)
    | LtExpr (l, r) -> LtExpr (j l, j r)
    | GtExpr (l, r) -> GtExpr (j l, j r) 
    | LteqExpr (l, r) -> LteqExpr (j l, j r)
    | GteqExpr (l, r) -> GteqExpr (j l, j r)
    | BitAndExpr (l, r) -> BitAndExpr (j l, j r)
    | BitOrExpr (l, r) -> BitOrExpr (j l, j r)
    | BitXorExpr (l, r) -> BitXorExpr (j l, j r)
    | ShiftLeftExpr (l, r) -> ShiftLeftExpr (j l, j r) 
    | SignedShiftRightExpr (l, r) -> SignedShiftRightExpr (j l, j r)
    | UnsignedShiftRightExpr (l, r) -> UnsignedShiftRightExpr (j l, j r) in
  let rec jimplify_stmt s =
    let postprocess_stmt s =
      if (!extra_stmts = []) then
        s
      else
        begin
          let q = CompoundStmt (!extra_stmts @ [s]) in
          extra_stmts := [];
          q
        end in
    let postprocess_stmt_to_list s =
      let ppsl s = 
        if (!extra_stmts = []) then
          [s]
        else
          begin
            let q = !extra_stmts @ [s] in
            extra_stmts := [];
            q
          end in
      List.concat (List.map 
                     (fun x -> match x with
                     | CompoundStmt cs -> cs
                     | _ -> [x]) (ppsl s)) in
    match s with
    | EmptyStmt | AssertStmt _ | PragmaStmt _ | HavocStmt _
    | AssumeStmt _ | ReturnStmt None -> s
    | CompoundStmt cs -> 
        CompoundStmt 
          (List.concat (List.map (fun x -> 
            postprocess_stmt_to_list (jimplify_stmt x)) cs))
    | ChoiceStmt (t, u) ->
        ChoiceStmt
          (postprocess_stmt (jimplify_stmt t),
           postprocess_stmt (jimplify_stmt u))
    | ExprStmt e -> postprocess_stmt (ExprStmt (jimplify_expr e))
    | LocalDeclStmt (v, t, e) ->
        postprocess_stmt (LocalDeclStmt (v, t, jimplify_expr e))
    | ReturnStmt (Some e) -> 
        postprocess_stmt (ReturnStmt (Some (jimplify_expr e)))
    | WhileStmt (i, e, w) ->
        let extra_stmts_start = !extra_stmts in
        let e' = jimplify_expr e in
        let extra_stmts_after_e = !extra_stmts in
        let rec chopper f fg = 
          match (f, fg) with
          | ([], gg) -> gg
          | (a::fs, b::fgs) when a = b -> chopper fs fgs
          | _ -> failwith "f not prefix of fg" in
        let rec undecl stmt = 
          match stmt with (* stupid short-circuit!*)
          | LocalDeclStmt (v, t, e) -> ExprStmt (AssignExpr (LocalLvalue v, e))
          | IfStmt (c, t, f) -> IfStmt (c, undecl t, undecl f)
          | ExprStmt e -> ExprStmt e
          | CompoundStmt cs -> CompoundStmt (List.map undecl cs)
          | EmptyStmt -> EmptyStmt
          | _ -> failwith "bad extra_stmt?!" in
        let extra_stmts' = !extra_stmts in
        extra_stmts := [];
        let extra_xs = chopper extra_stmts_start extra_stmts_after_e in
        let w' = postprocess_stmt (CompoundStmt (jimplify_stmt w :: 
                                                 List.map undecl extra_xs)) in
        extra_stmts := extra_stmts';
        postprocess_stmt (WhileStmt (i, e', w'))
    | IfStmt (e, t, f) -> postprocess_stmt 
          (IfStmt ((jimplify_expr e), 
                   postprocess_stmt (jimplify_stmt t),
                   postprocess_stmt (jimplify_stmt f))) in
  let jimplify_proc p = 
    { proc_id = p.proc_id;
      proc_modifiers = p.proc_modifiers;
      formals = p.formals;
      ret_val = p.ret_val;
      requires = p.requires;
      modifies = p.modifies;
      ensures = p.ensures;
      proc_body = jimplify_stmt p.proc_body } in
  { module_name = ast.module_name;
    instantiated_from = ast.instantiated_from;
    param_subst = ast.param_subst;
    formats = ast.formats;
    references = ast.references;
    procs = List.map jimplify_proc ast.procs;
  }

let instantiate_templates force ast = 
  let actuals = List.map snd ast.param_subst in
  let a_no_dups = Util.remove_dups actuals in
  if a_no_dups <> actuals then Util.err "[module instantiation]" ("Duplicated type parameter in impl module "^ast.module_name);
  match ast.instantiated_from with
  | None -> ast
  | Some parent ->
      let pmod = try Ast.fetch_impl parent 
      with Not_found -> 
        if force then 
          failwith ("Couldn't find instantiated module "^parent^".")
        else 
          ast (* not mandatory to instantiate modules in analysis *) in
      let sl = ast.param_subst in
      let rec subst_type t = 
        match t with
          TObj t' when List.mem_assoc t' sl ->
            TObj (List.assoc t' sl)
        | TArray t' -> TArray (subst_type t')
        | _ -> t in
      let subst_pair (x, y) = (x, subst_type y) in
      let subst_field_decl (x, y) = 
        (Id.fetch_field ast.module_name (Id.name_of_field x), subst_type y) in
      let subst_format fmt = {
        format_name = 
        if List.mem_assoc fmt.format_name sl then
          List.assoc fmt.format_name sl
        else 
          fmt.format_name;
        fields = List.map subst_field_decl fmt.fields;
      } in 
      let rec subst_lvalue lv = 
        match lv with
        | LocalLvalue v -> lv
        | RefLvalue rv -> lv
        | FieldLvalue (e', f) -> 
            let f' = Id.fetch_field ast.module_name (Id.name_of_field f) in
            FieldLvalue (subst_expr e', f') 
        | ArrayLvalue (e', i) -> ArrayLvalue (subst_expr e', 
                                              subst_expr i) 
      and subst_expr e = 
        let e' = real_subst_expr e in
        Exprtbl.replace Ast.expr_pos e' (Ast.lookup_expr_pos e);
        e'
      and real_subst_expr e = 
        let se = subst_expr in
        match e with
        | NewExpr n -> 
            if List.mem_assoc n sl then 
              NewExpr (List.assoc n sl)
            else e
        | LiteralExpr _ -> e
        | VarExpr lvalue -> VarExpr (subst_lvalue lvalue)
        | NewArrayExpr (t, e', d) -> 
            NewArrayExpr (subst_type t, List.map se e', d)
        | FieldAccessExpr (e', f) ->
            let f' = Id.fetch_field ast.module_name (Id.name_of_field f) in
            FieldAccessExpr (se e', f')
        | ArrayAccessExpr (e', i) ->
            ArrayAccessExpr (se e', se i)
        | ArrayLengthExpr e' ->
            ArrayLengthExpr (se e')
        | InvokeExpr (p, args) ->
            let p' = 
              (if (Id.module_of_proc p) = pmod.module_name then 
                (Id.fetch_proc ast.module_name (Id.name_of_proc p)) else p) in
            let args' = List.map se args in
            InvokeExpr (p', args')
        | AssignExpr (lhs, e') -> 
            AssignExpr (subst_lvalue lhs, se e')
        | PreIncExpr e' -> PreIncExpr (subst_lvalue e')
        | PostIncExpr e' -> PostIncExpr (subst_lvalue e')
        | PreDecExpr e' -> PreDecExpr (subst_lvalue e')
        | PostDecExpr e' -> PostDecExpr (subst_lvalue e')
        | NegExpr e' -> NegExpr (se e')
        | NotExpr e' -> NotExpr (se e')
        | PlusExpr (l, r) -> PlusExpr (se l, se r)
        | MinusExpr (l, r) -> MinusExpr (se l, se r)
        | MultExpr (l, r) -> MultExpr (se l, se r)
        | DivExpr (l, r) -> DivExpr (se l, se r)
        | ModExpr (l, r) -> ModExpr (se l, se r)
        | AndExpr (l, r) -> AndExpr (se l, se r) 
        | OrExpr (l, r) -> OrExpr (se l, se r)
        | EqExpr (l, r) -> EqExpr (se l, se r)
        | NeqExpr (l, r) -> NeqExpr (se l, se r)
        | LtExpr (l, r) -> LtExpr (se l, se r)
        | GtExpr (l, r) -> GtExpr (se l, se r) 
        | LteqExpr (l, r) -> LteqExpr (se l, se r)
        | GteqExpr (l, r) -> GteqExpr (se l, se r)
        | BitAndExpr (l, r) -> BitAndExpr (se l, se r)
        | BitOrExpr (l, r) -> BitOrExpr (se l, se r)
        | BitXorExpr (l, r) -> BitXorExpr (se l, se r)
        | ShiftLeftExpr (l, r) -> ShiftLeftExpr (se l, se r) 
        | SignedShiftRightExpr (l, r) -> SignedShiftRightExpr (se l, se r)
        | UnsignedShiftRightExpr (l, r) -> UnsignedShiftRightExpr (se l, se r) in
      let rec subst_stmt s = 
        match s with
        | CompoundStmt cs -> CompoundStmt (List.map subst_stmt cs)
        | ChoiceStmt (t, u) ->
            ChoiceStmt (subst_stmt t, subst_stmt u)
        | LocalDeclStmt (v, t, e) -> 
            LocalDeclStmt (v, subst_type t, subst_expr e)
        | IfStmt (c, t, f) -> 
            IfStmt (subst_expr c, subst_stmt t, subst_stmt f) 
        | ExprStmt e ->
            ExprStmt (subst_expr e)
        | EmptyStmt
        | PragmaStmt _ 
        | AssertStmt _ 
        | AssumeStmt _ 
        | HavocStmt _ 
        | ReturnStmt None -> s
        | WhileStmt (i, c, b) ->
            WhileStmt (i, subst_expr c, subst_stmt b) 
        | ReturnStmt (Some rv) -> ReturnStmt (Some (subst_expr rv)) in
      let subst_proc p = {
        proc_id = Id.fetch_proc ast.module_name (Id.name_of_proc p.proc_id);
        proc_modifiers = p.proc_modifiers;
        formals = List.map subst_pair p.formals;
        ret_val = (match p.ret_val with None -> None
        | Some x -> Some (subst_pair x));
        requires = p.requires;
        modifies = p.modifies;
        ensures = p.ensures;
        proc_body = subst_stmt p.proc_body;
      } in
      { 
        module_name = ast.module_name;
        instantiated_from = ast.instantiated_from;
        param_subst = ast.param_subst;
        formats = List.map subst_format pmod.formats;
        references = List.map subst_pair pmod.references;
        procs = List.map subst_proc pmod.procs;
      }

let rec flatten_compound_stmt s = 
  let rec fc x = List.concat (List.map flatten_compound0 x) 
  and flatten_compound0 cs = match cs with
  | CompoundStmt cs' -> List.concat (List.map flatten_compound0 cs')
  | _ -> [flatten_compound_stmt cs] in
  match s with
  | CompoundStmt cs -> 
      CompoundStmt (fc cs)
  | WhileStmt (i, e, CompoundStmt w') ->
      WhileStmt (i, e, CompoundStmt (fc w'))
  | IfStmt (e, t, f) -> 
      let t' = (match t with 
        CompoundStmt ts -> CompoundStmt (fc ts)
        | _ -> t) in
      let f' = (match f with 
        CompoundStmt fs -> CompoundStmt (fc fs)
      | _ -> f) in
      IfStmt (e, t', f')
  | _ -> s

(* move up local declarations to top procedure-level
 * and resolve conflicting names *)
let pull_up_locals ast =
  (*Exprtbl.clear Ast.expr_pos;*)
  let rec pull_up_stmt (s:'a stmt) : ('a stmt * 'a stmt list) =
    match s with
    | EmptyStmt | AssertStmt _ | PragmaStmt _ 
    | AssumeStmt _ | ReturnStmt _ | HavocStmt _
    | ExprStmt _ -> (s, [])
    | ChoiceStmt (t, u) ->
        let t' = pull_up_stmt t in
        let u' = pull_up_stmt u in
        (ChoiceStmt (fst t', fst u'), snd t' @ snd u')
    | CompoundStmt cs -> 
        let cs' = List.map pull_up_stmt cs in
        (CompoundStmt (List.map fst cs'), 
         List.concat (List.map snd cs'))
    | LocalDeclStmt (v, t, e) ->
        (ExprStmt (AssignExpr (LocalLvalue v, e)), 
         [LocalDeclStmt (v, t, Iabsyn.LiteralExpr (Iabsyn.initial_value t))])
    | WhileStmt (i, e, w) ->
        let w' = pull_up_stmt w in
        (WhileStmt (i, e, fst w'), snd w')
    | IfStmt (e, t, f) -> 
        let t' = pull_up_stmt t in
        let f' = pull_up_stmt f in
        (IfStmt (e, fst t', fst f'), snd t' @ snd f') in
  let pull_up_proc p = 
    let b' = pull_up_stmt p.proc_body in
    if (Util.find_dups (snd b') <> []) then
      begin
        let diff = Util.find_dups (snd b') in
        let s = function LocalDeclStmt (v, t, e) -> v | _ -> "" in
        let ds = Util.spacify " " (List.map s diff) in
        Util.err "[pulling up locals]" 
          ("Duplicate (hidden) local variable(s) "^
           ds ^ ": unsupported by us!")
      end;
    let b0 = match (fst b') with
    | CompoundStmt cs' -> cs'
    | _ -> [CompoundStmt [fst b']] in
    { proc_id = p.proc_id;
      proc_modifiers = p.proc_modifiers;
      formals = p.formals;
      ret_val = p.ret_val;
      requires = p.requires;
      modifies = p.modifies;
      ensures = p.ensures;
      proc_body = flatten_compound_stmt (CompoundStmt (snd b' @ b0)) } in
  { module_name = ast.module_name;
    instantiated_from = ast.instantiated_from;
    param_subst = ast.param_subst;
    formats = ast.formats;
    references = ast.references;
    procs = List.map pull_up_proc ast.procs;
  }

(* uses call graph and this impl to compute a list of reentrant sites *)
let collect_reentrant_sites (mi:string Iabsyn.impl_module)
    : (Iabsyn.expr list * Iabsyn.expr list) = 
  let rsM = ref [] in
  let rsS = ref [] in
  (!rsM, !rsS)

