open Id
open Types

(* Abstract Syntax for Implementation Language *)

(* heap elements *)
type value = 
    Int of int32
  | Bool of bool
  | Float of float
  | String of string
  | Char of char
  | Byte of char
  | Obj of int
  | Array of value array


let rec value_type_of_value x =
  match x with
  | Int _ -> TInt
  | Bool _ -> TBool
  | Float _ -> TFloat
  | String _ -> TString
  | Char _ -> TChar
  | Byte _ -> TByte
  | Obj _ -> (TObj Id.unknown_format)
  | Array [||] -> TArray TVoid
  | Array y -> TArray (value_type_of_value (y.(0)))
(* yes, we don't know the type of arrays of length 0 either. *)
(* in fact that would fail with array-out-of-bds *)

let null_obj = Obj 0

let initial_value x =
  match x with
  | TInt -> Int 0l
  | TBool -> Bool false
  | TFloat -> Float 0.
  | TString -> String ""
  | TChar -> Char (char_of_int 0)
  | TByte -> Byte (char_of_int 0)
  | TObj _ -> null_obj
  | TVoid -> failwith "no initial value for void"
  | TArray y -> Array [| |]
  | TTuple _ -> failwith "no initial value for relations"
  | TSet _ -> failwith "no initial value for sets"

(* program elements *)

type lvalue =
    LocalLvalue of var_t
  | RefLvalue of var_t
  | FieldLvalue of expr * field_t
  | ArrayLvalue of expr * expr
and expr =
    LiteralExpr of value
  | VarExpr of lvalue
  | FieldAccessExpr of expr * field_t
  | ArrayAccessExpr of expr * expr
  | ArrayLengthExpr of expr
  | NewExpr of Id.format_t
  | NewArrayExpr of value_type * expr list * int
  | InvokeExpr of proc_t * expr list
  | AssignExpr of lvalue * expr
  | PreIncExpr of lvalue | PostIncExpr of lvalue 
  | PreDecExpr of lvalue | PostDecExpr of lvalue
  | NegExpr of expr
  | PlusExpr of expr * expr
  | MinusExpr of expr * expr
  | MultExpr of expr * expr
  | DivExpr of expr * expr
  | ModExpr of expr * expr
  | AndExpr of expr * expr
  | OrExpr of expr * expr
  | NotExpr of expr
  | EqExpr of expr * expr
  | NeqExpr of expr * expr
  | LtExpr of expr * expr
  | GtExpr of expr * expr
  | LteqExpr of expr * expr
  | GteqExpr of expr * expr
  | BitAndExpr of expr * expr
  | BitOrExpr of expr * expr
  | BitXorExpr of expr * expr
  | ShiftLeftExpr of expr * expr
  | SignedShiftRightExpr of expr * expr
  | UnsignedShiftRightExpr of expr * expr

type 'asrt stmt =
    EmptyStmt
  | CompoundStmt of 'asrt stmt list
  | ChoiceStmt of 'asrt stmt * 'asrt stmt (* don't try to execute this! *)
  | LocalDeclStmt of var_t * value_type * expr
  | ExprStmt of expr 
    (* we should warn if not unit type *)
  | ReturnStmt of expr option
  | WhileStmt of 'asrt option * expr * 'asrt stmt
  | AssertStmt of string option * 'asrt
  | AssumeStmt of string option * 'asrt
  | HavocStmt of var_t list
  | PragmaStmt of string
  | IfStmt of expr * ('asrt stmt) * ('asrt stmt)

type format_decl = {
    format_name : format_t;
    fields      : (field_t * value_type) list
  }

type modifiers_t = {
    is_private : bool;
  }

type 'asrt proc_def = {
    proc_id    : proc_t;
    proc_modifiers : Id.modifiers_t;
    formals    : (var_t * value_type) list;
    ret_val    : (var_t * value_type) option;
    requires   : 'asrt option;
    ensures    : 'asrt option;
    modifies   : var_t list;
    proc_body  : 'asrt stmt
  }

type 'asrt impl_module = {
    module_name : module_t;
    instantiated_from : module_t option;
    param_subst : (format_t * format_t) list;
    formats     : format_decl list;
    references  : (var_t * value_type) list; (* all global vars *)
    procs       : ('asrt proc_def) list
  }

module E = 
  struct
    type t = expr
    let equal = (==)
    let hash = Hashtbl.hash
  end

module Exprtbl = Hashtbl.Make (E)

module S = 
  struct
    type t = Sabsyn.form stmt
    let equal = (==)
    let hash = Hashtbl.hash
  end

module Stmttbl = Hashtbl.Make (S)

let collect_callees pi = 
  let rec collect_callees_stmt s =
    match s with
    | EmptyStmt -> []
    | CompoundStmt sl -> List.concat (List.map collect_callees_stmt sl)
    | ChoiceStmt (t, u) -> collect_callees_stmt t @ collect_callees_stmt u
    | LocalDeclStmt (_, _, e) -> collect_callees_expr e
    | ExprStmt e -> collect_callees_expr e
    | ReturnStmt None -> []
    | ReturnStmt (Some e) -> collect_callees_expr e
    | WhileStmt (_, e, ss) -> 
        collect_callees_expr e @ collect_callees_stmt ss
    | AssertStmt _ | AssumeStmt _ -> []
    | HavocStmt _ -> []
    | PragmaStmt _ -> []
    | IfStmt (e, t, f) -> 
        collect_callees_expr e @ collect_callees_stmt t @ 
        collect_callees_stmt f 
  and collect_callees_expr e = 
    match e with 
    | FieldAccessExpr (e', _) ->
        collect_callees_expr e'
    | ArrayAccessExpr (e1, e2) ->
        collect_callees_expr e1 @ collect_callees_expr e2
    | ArrayLengthExpr e' ->
        collect_callees_expr e'
    | LiteralExpr _ | VarExpr _ 
    | NewExpr _ -> []
    | NewArrayExpr (_, el, _) -> 
        List.concat (List.map collect_callees_expr el)
    | AssignExpr (_, e') -> 
        collect_callees_expr e'
    | PreIncExpr _ | PostIncExpr _ | PreDecExpr _ | PostDecExpr _ -> []
    | NegExpr e' | NotExpr e' ->
        collect_callees_expr e'
    | PlusExpr (e1, e2) | MinusExpr (e1, e2) 
    | MultExpr (e1, e2) | DivExpr (e1, e2) 
    | ModExpr (e1, e2) | AndExpr (e1, e2) 
    | OrExpr (e1, e2) | EqExpr (e1, e2) 
    | NeqExpr (e1, e2) | LtExpr (e1, e2)
    | GtExpr (e1, e2) | LteqExpr (e1, e2)
    | GteqExpr (e1, e2) | BitAndExpr (e1, e2)
    | BitOrExpr (e1, e2) | BitXorExpr (e1, e2)
    | ShiftLeftExpr (e1, e2) | SignedShiftRightExpr (e1, e2)
    | UnsignedShiftRightExpr (e1, e2) ->
        collect_callees_expr e1 @ collect_callees_expr e2
    | InvokeExpr (p, el) ->
        p :: List.concat (List.map collect_callees_expr el) in
  collect_callees_stmt pi.proc_body

let collect_local_obj_type_map pi : 
    (Id.var_t list * Id.var_t list * (Id.var_t, value_type) Hashtbl.t) =
  let lnames = ref [] in
  let bnames = ref [] in
  let tenv = Hashtbl.create 1 in 
  let updateLNames (x,y) = Hashtbl.add tenv x y; 
    match y with
    | TObj _ -> lnames := x :: !lnames
    | TBool -> bnames := x :: !bnames
    | _ -> () in
  let rec collect_types s = match s with
  | LocalDeclStmt (v, t, _) -> updateLNames (v,t)
  | CompoundStmt cs -> List.iter collect_types cs
  | WhileStmt (_, _, b) -> collect_types b
  | IfStmt (_, t, f) -> collect_types f; collect_types t
  | _ -> () in 
  begin
    let fr = match pi.ret_val with
      None -> pi.formals
    | Some rv -> rv :: pi.formals in
    List.iter updateLNames fr;
    collect_types pi.proc_body;
    (!lnames, !bnames, tenv)
  end

let collect_obj_locals (s:'a stmt) = 
  (* find local variables of object type *)
  let rec collect s acc = match s with
  | LocalDeclStmt(v,Types.TObj _,_) -> v::acc
  | CompoundStmt ss -> List.fold_right collect ss acc
  | ChoiceStmt(s1,s2) -> collect s1 (collect s2 acc)
  | WhileStmt(_,_,ss) -> collect ss acc
  | IfStmt(_,t,f) -> collect t (collect f acc)
  | _ -> acc
  in collect s []
