let all_scopes () : Sabsyn.scope list = !Ast.scopes

let scopes_of (m:Id.module_t) : Sabsyn.scope list =
  List.filter (fun x -> List.mem m x.Sabsyn.modules) !Ast.scopes

let exporting_scopes_of (m:Id.module_t) : Sabsyn.scope list =
  List.filter (fun x -> List.mem m x.Sabsyn.exports) !Ast.scopes

let non_exporting_scopes_of (m:Id.module_t) : Sabsyn.scope list =
  Util.difference (scopes_of m) (exporting_scopes_of m)

let invariant_bearing_scopes (cl:Sabsyn.scope list) = 
  List.filter (fun x -> match x.Sabsyn.invariant with
  | None -> false
  | Some _ -> true) cl

(* checks the scope calling condition:
 * 1) scopes(M) \ scopes(p) \subseteq exportingScopes(M)
 * 2) scopes(M) \cap scopes(p) \cap scopes_with_invariant \subseteq yard(M) *)
let is_call_permissible (p:Sabsyn.proc_spec) (m:Id.module_t) =
  let scopes_p = scopes_of (Id.module_of_proc p.Sabsyn.proc_name) in
  let scopes_m = scopes_of m in
  let exporting_scopes_m = exporting_scopes_of m in
  let scopes_m_with_invariant = invariant_bearing_scopes scopes_m in
  let yard_m = Util.difference scopes_m exporting_scopes_m in
  List.for_all (fun x -> List.mem x exporting_scopes_m) 
    (Util.difference scopes_m scopes_p) &&
  List.for_all (fun x -> List.mem x yard_m)
    (Util.intersect scopes_p scopes_m_with_invariant)

(* returns true if for each scope shared between cm and m,
 * cm is exported and m is not exported (i.e. private) *)
let is_call_internal (cm:Id.module_t) (m:Id.module_t) = 
  cm = m or
  (let scopes_cm = scopes_of cm in
  let scopes_m = scopes_of m in
  let exporting_scopes_cm = exporting_scopes_of cm in
  let exporting_scopes_m = exporting_scopes_of m in
  let private_scopes_m = Util.difference scopes_m exporting_scopes_m in
  let shared_scopes = Util.intersect scopes_cm scopes_m in
  List.for_all (fun x -> List.mem x exporting_scopes_cm &&
    List.mem x private_scopes_m) shared_scopes)

(* module invariants are also active for that module *)
let fetch_active_invariants (ms:Sabsyn.spec_module) (p:Sabsyn.proc_spec) =
  let m = (Id.module_of_proc p.Sabsyn.proc_name) in
  let es = exporting_scopes_of m in
  let m_inv = 
    if (not (p.Sabsyn.proc_modifiers.Id.is_private)) then
      (List.map fst ms.Sabsyn.invariants) else [] in
  Sabsyn.And (m_inv @ (List.concat 
                (List.map (fun x -> match x.Sabsyn.invariant with 
                  None -> [] | Some i -> [fst i]) es)))

(* use this to get the proc when analyzing it, not at calling site *)
let invariantize (ms:Sabsyn.spec_module) (p:Sabsyn.proc_spec) =
  {
   Sabsyn.proc_name  = p.Sabsyn.proc_name;
   Sabsyn.proc_modifiers = p.Sabsyn.proc_modifiers;
   Sabsyn.formals    = p.Sabsyn.formals;
   Sabsyn.ret_val    = p.Sabsyn.ret_val;
   Sabsyn.suspends   = p.Sabsyn.suspends;
   Sabsyn.requires   = Sabsyn.mk_and [p.Sabsyn.requires; 
                                   fetch_active_invariants ms p];
   Sabsyn.modifies   = p.Sabsyn.modifies;
   Sabsyn.calls      = p.Sabsyn.calls;
   Sabsyn.extra_ensures = (Sabsyn.prime_form 
                             (fetch_active_invariants ms p) [], Sabsyn.reason_invariant) ::
                       p.Sabsyn.extra_ensures;
   Sabsyn.ensures    = p.Sabsyn.ensures
 }

let compute_hidden_sets ms callee =
  (* look for scopes C of ms;
     see if callee calls back into any such scopes *)
  let current_scopes = scopes_of ms.Sabsyn.module_name in
  let new_scopes = 
    scopes_of (Id.module_of_proc callee.Sabsyn.proc_name) in
  (*let scopes_lost = Util.difference current_scopes new_scopes in*)
  let scopes_gained = Util.difference new_scopes current_scopes in
  let modules_gained = 
    List.concat (List.map 
                   (fun z -> List.map Ast.fetch_spec z.Sabsyn.modules) 
                   scopes_gained) in
  let invisible_modules_gained = 
    List.filter (fun x -> 
      let x_scopes = 
        non_exporting_scopes_of (x.Sabsyn.module_name) in 
      List.exists (fun y -> not (List.mem y current_scopes)) x_scopes)
      modules_gained in
  let typed_sets_to_shield = 
    List.concat (List.map
                   Sabsyn.extract_qualified_specvar_type_pairs_from_module 
                   invisible_modules_gained) in
  typed_sets_to_shield
