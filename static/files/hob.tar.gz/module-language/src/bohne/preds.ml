module type PREDICATES =
  sig
    type pred = Bf.Bf.var (* = int *)
    type field = Vcform.typedVarIdent * bool
    type record = string * field list

    val null_pred : pred
    val null_name : string
    val free_var : Vcform.form
    val free_var_name : string
    val typed_free_var : Vcform.typedVarIdent
    (** reset module state *)
    val reset : unit -> unit
	
    (** add new predicate *) 
    val add_pred : bool -> string -> Vcform.form -> unit
    (** add predicate definition for program variable *)
    val add_var : Vcform.typedVarIdent -> bool -> bool -> unit
    (** add predicate for pre state *)
    val add_pre_pred : string -> string -> unit
    (** add record type definition *)
    val add_rec_def : string * Vcform.env -> unit
	
    (** get index of pred by name *)
    val get_pred : string -> pred
    (** get predicate name by index *)
    val get_pred_name : pred -> string
    (** get defining formula of pred by index *)
    val get_pred_def : pred -> Vcform.form
    (** [is_var i] checks wether [i] is a predicate of a program variable *)
    val is_var : int -> bool
    (** [is_const i] checks wether [i] is a constant predicate *)
    val is_const : int -> bool
    (** [is_pre_pred i] checks wether [i] is a predicate describung the pre state *)
    val is_pre_pred : int -> bool
    (** returns all names and defitions of predicates *)
    val get_all_preds : unit -> (string * Vcform.form) list
    (** return all predicates for program variables *)
    val get_all_vars : unit -> int list
    (** type environment for globals *)
    val get_global_env : unit -> Vcform.env
    (** type environment for locals *)
    val get_local_env : unit -> Vcform.env
    (** returns definitions of record types *)
    val get_rec_defs : unit -> record list
    (** returns maximal index of used predicates *)
    val get_max_index : unit -> int

    val fold_preds : ('a -> pred -> 'a) -> 'a -> 'a

    val print_preds : out_channel -> unit
  end

module Preds : PREDICATES =
  struct
    open Bf
      
    type pred = Bf.var
    type field = Vcform.typedVarIdent * bool
    type record = string * field list

    (* fixed prefixes, names, ... *)
    let var_prefix = ""

    let null_pred = 0
	
    let null_name = var_prefix ^ (Vcform.string_of_const Vcform.NullConst)
         
    let free_var_name = "v0"

    let free_var = Vcform.mk_var free_var_name
	
    let typed_free_var = (free_var_name, Vcform.TypeObjRef "")

    (* predicate definitions *)
    let pred_defs = Array.make Bf.var_max Vcform.mk_false
    
    let pred_names = Array.make Bf.var_max ""

    let var_preds = Array.make Bf.var_max false

    let const_preds = Array.make Bf.var_max false

    let pre_preds = Array.make Bf.var_max false

    let pred_indices = Hashtbl.create 0


    (* global environment *)
    let global_env = ref []

    (* local environment *)
    let local_env = ref []

    (* record type definitions *)
    let rec_defs = ref []
	
    let get_max_index () = Bf.vars () - 1

    let get_pred_def pred = pred_defs.(pred)
	
    let get_pred_name pred = pred_names.(pred)
	
    let get_pred pred_name = 
      try
	Hashtbl.find pred_indices pred_name 
      with Not_found -> 
	failwith (Printf.sprintf "Preds: unknown predicate name %s.\n" pred_name)
	  
    let is_var i = var_preds.(i)
	
    let is_const i = const_preds.(i)
	
    let is_pre_pred i = pre_preds.(i)
	
    let add_pred_def is_pre_pred is_const is_var_pred pred pred_def =
      let i = Bf.new_var () in
      Hashtbl.add pred_indices pred i;
      var_preds.(i) <- is_var_pred;
      const_preds.(i) <- is_const;
      pre_preds.(i) <- is_pre_pred;
      pred_names.(i) <- pred;
      pred_defs.(i) <- pred_def
	  
    let add_var (x, t) is_const is_local =
      let var_x = Vcform.mk_var x in
      let def_x = 
	match t with
	| Vcform.TypeObjRef _ -> Vcform.mk_eq (var_x, free_var) 
	| Vcform.TypeBool -> var_x
	| _ -> failwith "Preds.add_var: unsupported type"
      in
      let _ = add_pred_def false is_const true (var_prefix ^ x) def_x in
      if is_local then local_env := ((x, t), None)::!local_env
      else global_env := ((x, t), None)::!global_env

    let add_pred = add_pred_def false false
	
    let add_pre_pred p pre_p = 
      let pred_p = get_pred p in
      let _ = 
	if is_var pred_p then
	  let t = Vcform.get_type p (!local_env @ !global_env) in
	  local_env := ((pre_p, t), None)::!local_env
	else local_env := ((pre_p, Vcform.TypeSet (Vcform.TypeObjRef "")), None)::!local_env
      in	
      add_pred_def true true (is_var pred_p) pre_p (get_pred_def pred_p)
      
    let reset () = begin
      Bf.reset ();
      Hashtbl.clear pred_indices;
      global_env := [];
      local_env := [((free_var_name, Vcform.TypeObjRef ""), None)];
      rec_defs := [];
      let null_def = Vcform.mk_eq (Vcform.mk_null, free_var) in
      add_pred_def false true false null_name null_def
    end
	
    let add_rec_def (rname, fs) =
      let bb_flds, d_flds, rec_flds = 
	List.fold_left (fun (bb_flds, d_flds, rec_flds) f ->
	  match f with
	  | (fld, None) -> (f::bb_flds, d_flds, (fld, false)::rec_flds)
	  | (fld, Some fld_def) -> (bb_flds, f::d_flds, (fld, true)::rec_flds)) 
	  ([], [], []) fs
      in
      global_env := d_flds @ bb_flds @ !global_env;
      rec_defs := (rname, rec_flds)::!rec_defs

    let get_local_env () = !local_env 
	
    let get_global_env () = !global_env

    let get_rec_defs () = !rec_defs
	
    let get_all_preds () = 
      let preds = ref [] in
      for i = get_max_index () downto 0 do
	preds := (pred_names.(i), pred_defs.(i))::!preds
      done;
      !preds

    let fold_preds fn init =
      let acc = ref init in
      for i = 0 to get_max_index () do
	acc := fn !acc i
      done;
      !acc

    let get_all_vars () =
      fold_preds 
	(fun acc i -> 
	  if is_var i || i = null_pred then 
	    i::acc 
	  else acc) []
   	


    let print_preds outchan =
      List.iter (fun (p, d) -> 
	let def = 
	  if not (is_pre_pred (get_pred p)) then Vcform.isabelle_formula d
	  else "-"
	in 
	Printf.fprintf outchan
	  "%s(%s) : %s\n" p free_var_name def) 
	(get_all_preds ())
  end
