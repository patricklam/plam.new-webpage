(* Printing debug messages *)

(* debug level (0: debug messages disabled) *)
let debug_level = ref 0

let set_debug_level l = debug_level := l

let print_debug l msg =
  if l <= !debug_level then 
    (msg (); flush stdout) 
  else ()

let print_debug_nl l msg =
  if l <= !debug_level then 
    (msg (); print_newline (); flush stdout) 
  else ()

let phase l s fn x =
  print_debug l (fun () -> print_string (s ^ "..."));
  let res = fn x in
  print_debug_nl l (fun () -> print_string "done.");
  res


(* Printing comma separated lists, etc. *)

let opsl_convert op empty convert skip_first ls =
  let csl' ls = String.concat op (List.map convert ls) in
  if not skip_first then match ls with
  | [] -> empty
  | _ -> op ^ csl' ls
  else match ls with
  | [] -> empty
  | _ -> csl' ls

let csl_convert b ls = opsl_convert ", " "" b ls

let csl = csl_convert (fun x -> x) 

let print_opsl_convert chan op empty p skip_first ls = 
  let csl' ls = List.iter (fun x -> output_string chan op; p x) ls in
  if not skip_first then match ls with
  | [] -> output_string chan empty
  | _ -> csl' ls
  else match ls with
  | x::ls -> p x; csl' ls
  | [] -> output_string chan empty

let print_csl_convert chan b ls = print_opsl_convert chan ", " "" b ls

let print_csl chan = print_csl_convert chan (output_string chan)

(* Options *)

let unwrap default = function 
  | None -> default 
  | Some x -> x

let map_opt f = function 
  | None -> None 
  | Some x -> Some (f x)
