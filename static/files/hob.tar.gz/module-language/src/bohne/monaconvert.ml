(* ******************************************** *)
(*           Conversion from Vcform             *)
(* ******************************************** *)

open Bohneutil
open Monaform

let null_pred = Vcform.string_of_const Vcform.NullConst
let eq1_pred = "eq"
let elem_pred = "elem"
let nnull rname = rname ^ "_null" 
let nnode rname = rname ^ "_node"
let heap_type = "HEAP" 
let heap = "$Heap" 
let heap_var = mk_var2 heap 
let heap_bbtree = "BBTREE" 
let heap_bbroot = "bbroot"
let heap_empty = "EMPTY" 
let heap_next = "next" 
let graph_type = "GRAPHTYPE" 
let gtype_root rname = rname ^ "_root"   
let univ = "$U" 
let str_rtrancl = "rtrancl"

let fresh_var_name name c env = 
  let rec fvn i =
    let fresh_v = Printf.sprintf "%s%d" name i in
      if not (List.exists (fun ((v, _), _) -> v = fresh_v) env)
      then (c := i+1; fresh_v)
      else fvn (i+1)
  in fvn (!c)


module VOrder : Map.OrderedType 
with type t = Vcform.ident =
  struct
    type t = Vcform.ident
    let compare x y = String.compare x y
  end

module TVMap = Map.Make (VOrder)

exception NotMSO of string

let type_error t = "Monaconvert: type error in vcform " ^ Vcform.isabelle_formula t 
let desugar_error t = "Monaconvert: formula should have been desugared " ^ Vcform.isabelle_formula t 
let some_error t = "Monaconvert: error in vcform " ^ Vcform.isabelle_formula t 


(* remove lambda abstractions (currently only beta reduction) *)
let rec unlambda t =
  match t with
  | Vcform.App (Vcform.Binder (Vcform.Lambda, vs, t'), args) ->
      let sigma = 
	try List.map2 (fun (v, _) t -> (v, t)) vs args
	with Invalid_argument _ -> failwith (some_error t)
      in
      unlambda (Vcform.subst sigma t')
  | Vcform.App (t', ts) -> Vcform.App (unlambda t', List.map unlambda ts)
  | Vcform.Binder (b, vs, t') -> Vcform.Binder (b, vs, unlambda t')
  | Vcform.TypedForm (t', ty) -> Vcform.TypedForm (unlambda t', ty)
  | _ -> t
     

let desugar_rtrancl f =
  let pred_name = "$p" in
  let pred_type = Vcform.TypeFun ([Vcform.TypeUniverse; Vcform.TypeUniverse], Vcform.TypeBool) in
  let rtc = "$S" in
  let rtcvar = Vcform.mk_var rtc in
  let t1, t2 = (Vcform.mk_var "$t1", Vcform.mk_var "$t2") in
  let pred_app = Vcform.App (Vcform.mk_var pred_name, [Vcform.mk_var "$v1"; Vcform.mk_var "$v2"]) in
  let closed_t1 = 
    Vcform.mk_and [Vcform.mk_elem (t1, rtcvar); 
		   Vcform.mk_foralls ([("$v1", Vcform.TypeUniverse); ("$v2", Vcform.TypeUniverse)], 
				  (Vcform.mk_impl (Vcform.mk_and [Vcform.mk_elem (Vcform.mk_var "$v1", rtcvar); pred_app],
						   Vcform.mk_elem (Vcform.mk_var "$v2", rtcvar))))]
  in
  let rtrancl_def = Vcform.mk_foralls ([(rtc, Vcform.TypeSet Vcform.TypeUniverse)], Vcform.mk_impl (closed_t1, Vcform.mk_elem (t2, rtcvar))) in
  let rtrancl = Vcform.Binder (Vcform.Lambda, [(pred_name, pred_type); ("$t1", Vcform.TypeUniverse); ("$t2", Vcform.TypeUniverse)], rtrancl_def) in
  unlambda (Vcform.subst [(str_rtrancl, rtrancl)] f)



let rewrite_terms rewrite_rules genv f =
  let replace_map = Hashtbl.create 0 in
  let fresh_var_name = fresh_var_name "v" (ref 1) in
  let is_bound v env = List.exists (fun ((v', _), _) -> v = v') env in 
  let rec rewrite_terms rewrite_rules pol genv env f : (Vcform.form * Vcform.env * Vcform.env) =
  match rewrite_rules with
  | [] -> (f, genv, env)
  | r::rewrite_rules' -> 
      let mk_exists xs f =
	match xs with
	| [] -> f
	| _ -> Vcform.mk_exists (xs, f)
      in
      let rewrite_terms' = rewrite_terms rewrite_rules' in 
      let union accs =
	let exists, foralls, fs = List.fold_right (fun (l1, l2, l3) (l1s, l2s, l3s) -> (l1::l1s, l2::l2s, l3::l3s)) accs ([], [], []) in
	(List.concat exists, List.concat foralls, Vcform.smk_and fs)
      in
      let compose_exists f accs env =
	let exists, foralls, constr = union (([], [], f) :: accs) in
	let env' =  List.filter (fun (tv, _) -> not (List.mem tv exists)) env in
	(mk_exists exists constr, env')
      in
      let compose_foralls pol f bvs genv env =
	let is_bound t vs = List.exists (fun (x, _) -> 
	  List.mem x (Vcform.fv t) && not (is_bound x genv)) vs
	in
	let ts, vs = Hashtbl.fold (fun t v (ts, vs) ->
	  if is_bound t (vs @ bvs) then (t::ts, v::vs)
	  else (ts, vs)) replace_map ([], [])
	in
	let guards = List.map2 (fun t (v, _) -> 
	  Hashtbl.remove replace_map t;
	  Vcform.mk_eq (t, Vcform.mk_var v)) ts vs in
	let f' = 
	  if pol then
	    Vcform.mk_foralls (vs, Vcform.smk_impl (Vcform.smk_and guards, f))
	  else
	    Vcform.mk_exists (vs, Vcform.smk_and (f::guards)) in
	let env' =  List.filter (fun (tv, _) -> not (List.mem tv vs) &&  not (List.mem tv bvs)) env in
	(f', env')
      in
      let extend_env env (exists, foralls, _) =
	List.rev_map (fun v -> (v, None)) exists @
	List.rev_map (fun v -> (v, None)) foralls @ env 
      in
      let rec rewrite_atom pol genv env a : (Vcform.form * Vcform.env * Vcform.env) =
	match a with
	(* composed atoms *)
	| Vcform.App (Vcform.Const c, [t1; t2]) ->
	    (match c with
	    | Vcform.Eq | Vcform.Sub | Vcform.Elem | Vcform.Lt | Vcform.Gt
	    | Vcform.LtEq | Vcform.GtEq | Vcform.Disjoint ->
		let t1', acc1, genv' = r replace_map pol genv env t1 in
		let env' = extend_env env acc1 in
		let t2', acc2, genv' = r replace_map pol genv' env' t2 in
		let a', env' = compose_exists (Vcform.App (Vcform.Const c, [t1'; t2'])) [acc1; acc2] (extend_env env' acc2) in
		rewrite_terms' pol genv' env' a'
	    | _ -> failwith (type_error a))
	| _ -> (a, genv, env)
      in
      let rec rewrite_form pol genv env f : (Vcform.form * Vcform.env * Vcform.env) =
	match f with 
	(* Boolean connectives *)
	| Vcform.App (Vcform.Const c, fs) ->
	    (match (c, fs) with 
	    | (Vcform.Or, _) | (Vcform.And, _) | (Vcform.MetaAnd, _) -> 
		let fs', genv', env' = List.fold_right (fun f (fs', genv', env') -> 
		  let f', genv', env' = rewrite_form pol genv' env' f in (f'::fs', genv', env')) fs ([], genv, env)
		in (Vcform.App (Vcform.Const c, fs'), genv', env')
	    | (Vcform.Not, [f]) ->
		 let f', genv', env' = rewrite_form (not pol) genv env f in
		 (Vcform.App (Vcform.Const c, [f']), genv', env')
	    | (Vcform.Impl, [f1; f2]) | (Vcform.MetaImpl, [f1; f2]) ->
		let f1', genv', env' = rewrite_form (not pol) genv env f1 in
		let f2', genv', env' = rewrite_form pol genv' env' f2 in
		(Vcform.App (Vcform.Const c, [f1'; f2']), genv', env')
	    | (Vcform.Iff, [f1; f2]) ->
		let f11, genv', env' = rewrite_form (not pol) genv env f1 in
		let f21, genv', env' = rewrite_form (not pol) genv' env' f2 in
		let f12, genv', env' = rewrite_form pol genv' env' f1 in
		let f22, genv', env' = rewrite_form pol genv' env' f2 in
		if f11 = f12 && f21 = f22 then
		  (Vcform.App (Vcform.Const c, [f11; f21]), genv', env')
		else
		  (Vcform.smk_and [Vcform.smk_impl (f11, f22);
				   Vcform.smk_impl (f21, f12)], genv', env')
	    | _ -> rewrite_atom pol genv env f)
	(* binders *)
	| Vcform.Binder (b, vs, f) ->
	    (* make names of bound variables unique *)
	    let used_vars = List.rev_map (fun v -> (v, None)) vs @ env @ genv in
	    let vs', sigma = List.fold_right (fun (v, ty) (vs', sigma) ->
	      if is_bound v (env @ genv) then
		let v' = fresh_var_name used_vars in
		((v', ty)::vs', (v, Vcform.mk_var v')::sigma)
	      else ((v, ty)::vs', sigma)) vs ([], [])
	    in 
	    let f' = match sigma with [] -> f | _ -> Vcform.subst sigma f in
	    let f', genv', env' = rewrite_form pol genv ((List.map (fun tv -> (tv, None)) vs') @ env) f' in
	    let f', env' = compose_foralls pol f' vs' genv' env' in
	    (Vcform.Binder (b, vs', f'), genv', env')
	(* predicates *) 
	| Vcform.App (Vcform.Var v, es) ->
	    let es', accs, genv', env' = List.fold_right (fun e (es', accs, genv', env') -> 
	      let e', acc, genv' = r replace_map pol genv' env' e in 
	      (e'::es', acc::accs, genv', extend_env env' acc)) es ([], [], genv, env)
	    in
	    let f', env' = compose_exists (Vcform.App (Vcform.Var v, es')) accs env' in
	    rewrite_terms' pol genv' env' f'
	| _ -> rewrite_atom pol genv env f
      in rewrite_form pol genv env f
  in 
  let f', genv', _ = rewrite_terms rewrite_rules true genv [] f in
  (f', genv')


(* Rewrite rule for removal of FieldReads/FieldWrites *)
(* Precondition: no lambdas in term t *)

let rewrite_FieldRead_FieldWrite replace_map pol genv env t =
  let fresh_var_name = fresh_var_name "v" (ref 1) in
  let union accs =
    let exists, foralls, fs = List.fold_right (fun (l1, l2, l3) (l1s, l2s, l3s) -> (l1::l1s, l2::l2s, l3::l3s)) accs ([], [], []) in
    (List.concat exists, List.concat foralls, Vcform.smk_and fs)
  in
  let rec remove t upd_args = 
    match t with
    (* FieldRead *)
    | Vcform.App (Vcform.Const Vcform.FieldRead, t::ts) -> 
	remove (Vcform.App (t, ts)) upd_args
    (* start of FieldWrite sequence *)
    | Vcform.App (Vcform.App (Vcform.Const Vcform.FieldWrite, _) as fld, [arg]) ->
	let arg', acc_arg = remove arg None in
	let rhs = fresh_var_name (env @ genv) in
	let fld', acc_fld = remove fld (Some (arg', rhs, [], [], Vcform.mk_true)) in
	(Vcform.mk_var rhs, union [acc_arg; acc_fld])
    (* FieldWrite *)
    | Vcform.App (Vcform.Const Vcform.FieldWrite, [fd; ind; upd]) ->
	(match upd_args with
	| Some (arg, rhs, inds, updates, guard) ->
	    let ind', acc_ind = remove ind None 
	    and upd', acc_upd = remove upd None in
	    let g = Vcform.mk_neq (ind', arg) in
	    let guard' = Vcform.smk_and [g;guard] in
	    let update = 
	      if List.mem ind' inds then Vcform.mk_false else
	      Vcform.smk_and [guard; Vcform.mk_eq (ind', arg); Vcform.mk_eq (upd', Vcform.mk_var rhs)]
	    in
	    let fd', acc_fd = remove fd (Some (arg, rhs, ind'::inds, update::updates, guard')) in
	    (fd', union [acc_ind; acc_upd; acc_fd])
	| _ -> failwith (type_error t))
    | Vcform.App (fld, args) -> 
	let args', acc_args = 
	  List.fold_right (fun arg (args', acc_args) ->
	    let arg', acc_arg = remove arg None in
	    (arg' :: args', acc_arg :: acc_args)) args ([], [])
	and fld', acc_fld = remove fld None in
	(Vcform.App (fld', args'), union acc_args) 
    | Vcform.Var _ | Vcform.Const _ ->
	(match upd_args with
	(* end of FieldWrite sequence *)
	| Some (arg, rhs, _, updates, guard) -> 
	    let upd_form = 
	      Vcform.mk_or 
		(Vcform.smk_and [guard; Vcform.mk_eq (Vcform.App (t, [arg]), Vcform.mk_var rhs)]
		 :: updates)
	    in (t, ([(rhs, Vcform.TypeObjRef "")], [], upd_form))
	| _ -> (t, ([], [], Vcform.mk_true)))
    | _ -> failwith (some_error t)
  in
  let t', acc = remove t None in
  (t', acc, genv)


(* Rewrite rule for unnesting of field applications *)
(* Precondition: no lambdas in term t *)

let rewrite_unnest replace_map pol genv env t =
  let fresh_var_name = fresh_var_name "v" (ref 1) in
  let flatten_term t =
    let rec flatten_term t ty eqs new_vs =
      match t with
      |	Vcform.Var _ | Vcform.Const _ -> (t, eqs, new_vs)
      |	Vcform.App (fun_t, ts) ->
	  let fresh_v = fresh_var_name (env @ genv) in
	  let arg_tys, res_ty = 
	    match fun_t with
	    | Vcform.Var v ->
		(match  Vcform.get_type v (env @ genv) with 
		| Vcform.TypeFun ty -> ty
		| _ -> failwith (type_error t))
	    | Vcform.Const Vcform.FieldWrite ->
		([Vcform.TypeFun ([Vcform.TypeObjRef ""], Vcform.TypeVar "");
		  Vcform.TypeObjRef ""; Vcform.TypeVar ""],
		 Vcform.TypeFun ([Vcform.TypeObjRef ""], Vcform.TypeVar ""))
	    | Vcform.Const Vcform.FieldRead ->
		([Vcform.TypeFun ([Vcform.TypeObjRef ""], Vcform.TypeVar "");
		  Vcform.TypeObjRef ""], Vcform.TypeVar "")
	    | Vcform.Const c -> 
		(match
		  try List.assoc c Vcform.globalEnv with
		  | Not_found -> failwith (some_error t)
		with
		| Vcform.TypeFun ty -> ty
		| _ -> failwith (type_error t))
	    | Vcform.App (Vcform.Const Vcform.FieldWrite, _)
	      -> ([Vcform.TypeObjRef ""], Vcform.TypeVar "")
	    | _ -> failwith (some_error t)
	  in
	  let ts', eqs', new_vs' = 
	    List.fold_right2 
	      (fun t ty (ts, eqs, new_vs) ->
		let t', eqs', new_vs' = flatten_term t ty eqs new_vs in
		(t'::ts, eqs', new_vs'))  ts arg_tys ([], eqs, new_vs)
	  in
	  let fun_t', eqs', new_vs' = 
	    flatten_term fun_t Vcform.TypeUniverse eqs' new_vs' in
	  let t' = Vcform.App (fun_t', ts') in
	  (Vcform.Var fresh_v, (t', Vcform.Var fresh_v)::eqs', 
	   (fresh_v, res_ty)::new_vs')
      | Vcform.TypedForm (t, ty) -> 
	  let t', eqs', new_vs' = flatten_term t ty eqs new_vs in
	  (Vcform.TypedForm (t', ty), eqs', new_vs')
      |	_ -> failwith (some_error t)
    in match t with
    | Vcform.Var _ -> (t, ([], [], Vcform.mk_true))
    | _ -> 
	let t', eqs, new_vs = flatten_term t Vcform.TypeUniverse [] [] in 
	(t', (new_vs, [], Vcform.smk_and (List.map Vcform.mk_eq eqs)))
  in 
  let t', acc = flatten_term t in
  (t', acc, genv)

(* Rewrite rule for handling of ground derived fields        *)
(* Preconditions:                                            *)
(* - all fields are atomic, i.e. in particular no            *)
(*   FieldRead/FieldWrite                                    *)
(* - field constraints are of the form (lambda v1 v2. c) and *)
(*   given in global environment                             *)

let rewrite_derived_fields skolemize replace_map pol genv env t =
  let fresh_const = fresh_var_name "c" (ref 1) in
  let field_constraints = Hashtbl.create 0 in
  let _ = List.iter (function 
    | ((fld, _), Some (Vcform.Binder (Vcform.Lambda, [v1; v2], fld_def))) -> 
	Hashtbl.add field_constraints fld (v1, v2, fld_def)
    | _ -> ()) genv
  in
  let is_derived_field = Hashtbl.mem field_constraints in
  let is_bound v = List.exists (fun ((v', _), _) -> v = v') env in 
  let rec rewrite_ground_derived_fields t =
    match t with
    | Vcform.Var v -> (t, [], [], not (is_bound v))
    | Vcform.Const _ -> (t, [], [], true)
    | Vcform.App (fun_t, ts) ->
	let ts', new_consts, new_vars, is_ground = List.fold_right 
	    (fun t (ts', new_consts, new_vars, is_ground) ->
	      let t', new_consts', new_vars', is_ground' = rewrite_ground_derived_fields t in
	      (t'::ts', new_consts' @ new_consts, new_vars' @ new_vars, is_ground && is_ground'))  
	    ts ([], [], [], true)
	in
	let t' = Vcform.App (fun_t, ts') in
	(match (fun_t, ts') with 
	| (Vcform.Var fld, [arg]) when is_derived_field fld && (skolemize && is_ground || pol) ->
	    let (v1, ty1), (v2, ty2), fld_def = Hashtbl.find field_constraints fld in
	    let const, new_consts', new_vars' =
	      try (Vcform.mk_var (fst (Hashtbl.find replace_map t')), new_consts, new_vars)
	      with Not_found ->
		let fresh_c = fresh_const (env @ genv) in
		let c = Vcform.mk_var fresh_c in
		let c_decl = ((fresh_c, ty2), Some (Vcform.subst [(v1, arg); (v2, c)] fld_def)) in
		let new_consts', new_vars' = 
		  if skolemize && is_ground then 
		    (c_decl::new_consts, new_vars) 
		  else (new_consts, (fresh_c, ty2)::new_vars)
		in
		let _ = Hashtbl.add replace_map t' (fresh_c, ty2) in
		(c, new_consts', new_vars')
	    in
	    (const, new_consts', new_vars', is_ground)
	| _ -> (t', new_consts, new_vars, is_ground))
    | Vcform.TypedForm (t, ty) -> 
	let t', new_consts, new_vars, is_ground = rewrite_ground_derived_fields t in
	(Vcform.TypedForm (t', ty), new_consts, new_vars, is_ground)
    | _ -> failwith (desugar_error t)
  in 
  match t with
  | Vcform.Var _ -> (t, ([], [], Vcform.mk_true), genv)
  | _ -> 
      let t', new_consts, new_vars, _ = rewrite_ground_derived_fields t in
      let genv' = new_consts @ genv in
      (t', ([], new_vars, Vcform.mk_true), genv')
  

(* Precondition:                               *)
(* - no FealdRead/FealdWrites                  *)
(* - all functions unnested                    *)

let convert_vcform_helper env f =
  let _ = print_debug 4 (fun () -> print_string (Vcform.isabelle_formula f ^ "\n")) in 
  let type_error t = "Monaconvert: type error in vcform " ^ Vcform.isabelle_formula t in
  let untyped_var_error v = 
    Printf.sprintf "Monaconvert: variable %s is untyped" v in
  let union tvs1 tvs2 = TVMap.fold (fun v ty tvs -> TVMap.add v ty tvs) tvs2 tvs1 in
  let tvmap v ty = TVMap.add v ty TVMap.empty in 
  let rec order ty =
    match ty with
    | Vcform.TypeBool -> 0
    | Vcform.TypeVar _ -> 1
    | Vcform.TypeInt -> 1
    | Vcform.TypeVoid -> 0
    | Vcform.TypeObjRef _ -> 1
    | Vcform.TypeArray ty -> max 2 (order ty)
    | Vcform.TypeSet ty -> order ty + 1
    | Vcform.TypeList ty -> order ty + 1
    | Vcform.TypeFun (tys, ty) -> List.fold_left (fun m ty -> max (order ty + 1) m) (order ty) tys
    | Vcform.TypeUniverse -> failwith "Monaconvert: TypeUniverse has no defined order"
  in
  let rec is_mso ty =
    match ty with 
    | Vcform.TypeBool -> true
    | Vcform.TypeVar _ | Vcform.TypeObjRef _ -> true
    | Vcform.TypeSet (Vcform.TypeVar _) -> true
    | Vcform.TypeFun ([Vcform.TypeVar _], Vcform.TypeBool) -> true 
    | Vcform.TypeSet (Vcform.TypeObjRef _) -> true
    | Vcform.TypeFun ([Vcform.TypeObjRef _], Vcform.TypeBool) -> true 
    | _ -> false 
  in
  let rec convert_term1 env t = 
    match t with
    | Vcform.App (Vcform.Const c, ts) ->
	failwith (desugar_error t)
    | Vcform.Var v ->
	(mk_var1 v, tvmap v (Vcform.TypeObjRef ""))
    | Vcform.Const Vcform.NullConst -> 
	(mk_var1 null_pred, TVMap.empty) 
    | _ -> failwith (type_error t)
  in
  let rec convert_term2 env t = 
    match t with
    | Vcform.App (Vcform.Const c, t1::ts) ->
	let combine f (t1, tvs1) t2 = 
	  let t2, tvs2 = convert_term2 env t2 in
	  (f t1 t2, union tvs1 tvs2) in
	(match c with
	| Vcform.Cap ->
	    List.fold_left (combine mk_inter)
	      (convert_term2 env t1) ts
	| Vcform.Cup ->
	    List.fold_left (combine mk_union)
	      (convert_term2 env t1) ts
	| Vcform.Diff ->
	    (match ts with
	    | [t2] -> combine mk_diff (convert_term2 env t1) t2
	    | _ -> failwith (type_error t))
	| Vcform.FiniteSetConst 
	| Vcform.EmptysetConst -> failwith "unimplemented"
	| _ -> failwith (type_error t))
    | Vcform.Var v -> (mk_var2 v, tvmap v (Vcform.TypeSet (Vcform.TypeVar "")))
    | _ -> failwith (type_error t)
  in
  let convert_binder b vs f tvs =
    let vs' = List.fold_left
	(fun vs' (v, _) -> 
	  try 
	    let ty = TVMap.find v tvs in
	    if is_mso ty then (v, ty)::vs' else
	    raise (NotMSO (Printf.sprintf "Monaconvert: failed to quantify \
			     %s which might have higher-order type" v))
	  with Not_found -> vs') [] vs in
    let v0s, v1s, v2s = 
      List.fold_left 
	(fun (v0s, v1s, v2s) (v, ty) -> 
	  match order ty with
	  | 0 -> (v::v0s, v1s, v2s)
	  | 1 -> (v0s, v::v1s, v2s)
	  | 2 -> (v0s, v1s, v::v2s)
	  | _ -> (v0s, v1s, v2s)) ([], [], []) vs' in
    let tvs' = List.fold_left (fun tvs' (v,_) -> TVMap.remove v tvs') tvs vs in
    (match b with
    | Vcform.Forall -> (mk_all2 v2s (mk_all1 v1s (mk_all0 v0s f)), tvs')
    | Vcform.Exists -> (mk_ex2 v2s (mk_ex1 v1s (mk_ex1 v0s f)), tvs')
    | Vcform.Lambda -> 
	raise (NotMSO "Monaconvert: unable to convert lambda terms")
    | Vcform.Comprehension ->
	raise (NotMSO "Monaconvert: unable to convert comprehensions"))
  in
  let rec mk_pred env v ts res_opt tvs =
    let arg_tys, res_ty =
      match Vcform.get_type v env with
      | Vcform.TypeFun tys -> tys
      |	t -> ([], t)
    in 
    let ts, tys = match res_opt with
    | Some t -> 
	(t::List.rev ts, res_ty::List.rev arg_tys)
    | None when res_ty = Vcform.TypeBool -> 
	(List.rev ts, List.rev arg_tys)
    | _ -> failwith "Monaconvert: type error in vcform"
    in
    let es, tvs = 
      try List.fold_left2 
	  (fun (ts, tvs) e arg_ty -> 
	    (match order arg_ty with
	    | 0 -> let t, t_tvs = convert_form env e in
	      (Form t::ts, union t_tvs tvs)
	    | 1 -> let t, t_tvs = convert_term1 env e in
              (Term1 t::ts, union t_tvs tvs)
	    | 2 -> let t, t_tvs = convert_term2 env e in
	      (Term2 t::ts, union t_tvs tvs)
	    | _ -> raise (NotMSO "Monaconvert: vcform not in MSO")))
	  ([], tvs) ts tys
      with Invalid_argument _ -> failwith "Monaconvert: some error"
    in
    (Pred (v, es), tvs)
  and convert_atom env a =
    match a with
    | Vcform.Const (Vcform.BoolConst true) -> (mk_true, TVMap.empty)
    | Vcform.Const (Vcform.BoolConst false) -> (mk_false, TVMap.empty)
    | Vcform.Var v -> mk_pred env v [] None (tvmap v Vcform.TypeBool)
    | Vcform.App (Vcform.Const c, [t1; t2]) ->
	(match c with
	| Vcform.Eq -> 
	    (match (t1, t2) with
	    | (Vcform.App (Vcform.Var fld, args), _) 
	    | (_, Vcform.App (Vcform.Var fld, args))
	      -> mk_pred env fld args (Some t2) TVMap.empty
	    | _ -> (try
		let t1, tvs1 = convert_term1 env t1
		and t2, tvs2 = convert_term1 env t2 in
		(mk_eq1 t1 t2, union tvs1 tvs2)
	    with _ -> 
	      let t1, tvs1 = convert_term2 env t1
	      and t2, tvs2 = convert_term2 env t2 in
	      (mk_eq2 t1 t2, union tvs1 tvs2)))
	| Vcform.Sub -> 
	    let t1, tvs1 = convert_term2 env t1
	    and t2, tvs2 = convert_term2 env t2 in
	    (mk_sub t1 t2, union tvs1 tvs2)
	| Vcform.Elem -> 
	    let t1, tvs1 = convert_term1 env t1
	    and t2, tvs2 = convert_term2 env t2 in
            (mk_elem t1 t2, union tvs1 tvs2)
	| Vcform.Disjoint -> failwith "disjoint unimplemented"
	| Vcform.Lt
	| Vcform.Gt
	| Vcform.LtEq
	| Vcform.GtEq -> failwith "int relations unimplemented"
	| _ -> failwith (type_error a))
    | _ -> failwith (some_error a)
  and convert_form env f =
    match f with
    (* boolean connectives *)
    | Vcform.App (Vcform.Const c, fs) ->
	(match c with 
	| Vcform.Or -> 
	    let fs', tvs = List.split (List.map (convert_form env) fs) in
	    (mk_or fs', List.fold_left union TVMap.empty tvs)
	| Vcform.And -> 
	    let fs', tvs = List.split (List.map (convert_form env) fs) in
	    (mk_and fs', List.fold_left union TVMap.empty tvs)
	| Vcform.MetaAnd -> failwith "unimplemented"
	| Vcform.Not -> (match fs with
	  | [f] -> 
	      let f', tvs = convert_form env f in
	      (mk_not f', tvs)
	  | _ -> failwith (type_error f))
	| Vcform.Impl -> (match fs with
	  | [f1; f2] -> 
	      let f1, tvs1 = convert_form env f1
	      and f2, tvs2 = convert_form env f2 in
	      (mk_impl f1 f2, union tvs1 tvs2)
	  | _ -> failwith (type_error f))
	| Vcform.MetaImpl -> failwith "unimplemented"
	| Vcform.Iff -> (match fs with
	  | [f1; f2] -> 
	      let f1, tvs1 = convert_form env f1
	      and f2, tvs2 = convert_form env f2 in
	      (mk_iff f1 f2, union tvs1 tvs2)
	  | _ -> failwith (type_error f))
	| _ -> convert_atom env f)
    (* predicates *) 
    | Vcform.App (Vcform.Var v, es) ->
	mk_pred env v es None TVMap.empty
    (* quantifiers *)
    | Vcform.Binder (b, vs, f) ->
	let f', tvs = convert_form ((List.map (fun tv -> (tv, None)) vs) @ env) f in
	convert_binder b vs f' tvs
    | _ -> convert_atom env f
  in
  fst (convert_form env f)


let convert_vcform_rewrite_derived env f =
  let f = desugar_rtrancl f in
  let rewrite_rules =
    [rewrite_FieldRead_FieldWrite; 
     rewrite_derived_fields true;
     rewrite_unnest] 
  in
  let f', env' = rewrite_terms rewrite_rules env f in
(*  let _ = print_endline ("\n" ^ Vcform.isabelle_formula f') in *)
  let f_res = convert_vcform_helper env' f' in
  (f_res, env')
    
let convert_vcform env f =
  let f = desugar_rtrancl f in
  let rewrite_rules =
    [rewrite_FieldRead_FieldWrite;
     rewrite_derived_fields false;
     rewrite_unnest] 
  in
  let f', env' = rewrite_terms rewrite_rules env f in
  let f_res = convert_vcform_helper env' f' in
  (f_res, env')


(* finalize formulas: 
 * - restrict domain of quantifiers
 * - approximate positive occurences of derived fields
 * - convert occurences of null and equality 
 *)


let finalize env q1_guard q2_guard f =
  let fresh_var_name = fresh_var_name "v" (ref 1) in
  let is_derived_field f = 
    List.exists (fun ((f',_), def) -> f' = f && not (def = None)) env
  in
  let q1_guard = List.rev_map q1_guard in
  let q2_guard = List.rev_map q2_guard in
  let mk_eq1 t1 t2 = mk_pred eq1_pred [Term1 t1; Term1 t2] in
  let rec ag env pol f =
    let ag_letdef env pol defs =
      List.rev_map (fun (v, f) -> (v, ag env pol f)) defs 
    in
    match f with
    | Not f -> Not (ag env (not pol) f)
    | And fs -> And (List.rev_map (ag env pol) fs)
    | Or fs -> Or (List.rev_map (ag env pol) fs)
    | Impl (f1, f2) -> Impl (ag env (not pol) f1, ag env pol f2)
    | Iff (f1, f2) -> 
	mk_and [mk_impl (ag env (not pol) f1) (ag env pol f2);
		mk_impl (ag env (not pol) f2) (ag env pol f1)]
    | Restrict f -> Restrict (ag env pol f)
    | Prefix0 f -> Prefix0 (ag env pol f)
    | Pred (p, es) ->
	let fresh_var = fresh_var_name env in
	let found_null, es' =
	  List.fold_right (fun t (found_null, acc) -> 
	    match t with
	    | Form f -> (found_null, Form (ag env pol f)::acc)
	    | Term1 (Var1 v) when v = null_pred ->
		(true, Term1 (Var1 fresh_var)::acc)
	    | _ -> (found_null, t::acc)) es (false, []) 
	in
	let f' = 
	  match es' with
	    (* approximate positive occurrence of derived fields *)
	  | [Term1 t1; Term1 t2] when pol && is_derived_field p ->
	      failwith "found non-eliminated positive occurrence of derived field"
	  | _ -> Pred (p, es') 
	in 
	(* convert null to predicate *)
	if found_null then 
	  Quant (Exists1, [], [fresh_var], 
		 And [f'; mk_pred null_pred [Term1 (Var1 fresh_var)]])
	else f' 
    | Export (fname, f) -> mk_export fname (ag env pol f)
    | Quant (q, us, vs, f') ->
	let env' =  List.map (fun v -> ((v, Vcform.TypeUniverse), None)) vs @ env in
	(match q with
	| Exists1 -> Quant (q, us, vs, mk_and (ag env' pol f'::q1_guard vs))
	| Exists2 -> Quant (q, us, vs, mk_and (ag env' pol f'::q2_guard vs))
	| Forall1 -> Quant (q, us, vs, mk_impl (And (q1_guard vs)) (ag env' pol f'))
	| Forall2 -> Quant (q, us, vs, mk_impl (And (q2_guard vs)) (ag env' pol f'))
	| _ -> Quant (q, us, vs, ag env' pol f'))
    | Let0 (defs, f') -> 
	let env' = List.map (fun (v, _) -> ((v, Vcform.TypeUniverse), None)) defs @ env in
	Let0 (ag_letdef env pol defs, ag env' pol f')
    | Let1 (defs, f') ->
	let env' = List.map (fun (v, _) -> ((v, Vcform.TypeUniverse), None)) defs @ env in
	Let1 (ag_letdef env pol defs, ag env' pol f')
    | Let2 (defs, f') -> 
	let env' = List.map (fun (v, _) -> ((v, Vcform.TypeUniverse), None)) defs @ env in
	Let2 (ag_letdef env pol defs, ag env' pol f')
    | Atom (Eq1 (Var1 v, t)) when v = null_pred -> mk_pred null_pred [Term1 t]
    | Atom (Eq1 (t, Var1 v)) when v = null_pred -> mk_pred null_pred [Term1 t]
    | Atom (Eq1 (t1, t2)) -> mk_eq1 t1 t2
    | Atom (Neq1 (Var1 v, t)) when v = null_pred -> Not (mk_pred null_pred [Term1 t])
    | Atom (Neq1 (t, Var1 v)) when v = null_pred -> Not (mk_pred null_pred [Term1 t])
    | Atom (Neq1 (t1, t2)) -> Not (mk_eq1 t1 t2)
    | Atom (Elem (Var1 v, t)) when v = null_pred -> 
       mk_ex1 ["$v"] (mk_and [mk_pred null_pred [Term1 (Var1 "$v")]; mk_elem (Var1 "$v") t])
    | Atom (Elem (t1, t2)) -> mk_pred elem_pred [Term1 t1; Term2 t2]
    | Atom (Nelem (Var1 v, t)) when v = null_pred -> 
	mk_all1 ["$v"] (mk_impl (mk_pred null_pred [Term1 (Var1 "$v")]) (mk_nelem (Var1 "$v") t))
    | Atom (Nelem (t1, t2)) -> Not (mk_pred elem_pred [Term1 t1; Term2 t2])
    | _ -> f
  in
  ag env true f

(* convert environment to MONA declarations *)

let convert_env mk_sometype q1_guard q2_guard mode env vars =
  let us = match mode with | Ws2s -> [univ] | _ -> [] in
  let used_vars = Hashtbl.create 0 in
  let add_used_vars f = 
    List.iter (fun x -> Hashtbl.replace used_vars x ()) (Vcform.fv f)
  in  
  let _ = List.iter (fun x -> Hashtbl.replace used_vars x ()) vars in
  let is_used_var = Hashtbl.mem used_vars in
  let mk_null v = mk_pred null_pred [Term1 v] in
  let convert env f = finalize env q1_guard q2_guard (fst (convert_vcform env f)) in
  let process_env_decl decls ((x, t), f_opt) =
    if is_used_var x then
      let var1_def rname = 
	match mode with
	| Ws2s -> 
	    let x_type = 
	      if rname = "" then mk_sometype (mk_var1 x) 
	      else mk_type (mk_var1 x) rname 
	    in
	    mk_and [mk_elem (mk_var1 x) heap_var; x_type]
	| _ -> mk_true
      in
      let var2_def rname = 
	match mode with 
	| Ws2s ->
	    let x_type = 
	      if rname = "" then
		mk_all1 ["$v"] (mk_impl (mk_elem (mk_var1 "$v") (mk_var2 x)) (mk_sometype (mk_var1 "$v")))
	      else mk_all1 ["$v"] (mk_impl (mk_elem (mk_var1 "$v") (mk_var2 x)) (mk_type (mk_var1 "$v") rname))
	    in
	    mk_and [mk_sub (mk_var2 x) heap_var; x_type]
	| _ -> mk_true
      in
      match t with
      (* set of objects *)
      | Vcform.TypeSet (Vcform.TypeObjRef rname) ->
	  let f_opt' = match f_opt with
	  |  Some f -> 
	      let _ = add_used_vars f in
	      Some (mk_and [var2_def rname; convert env f])
	  | _ -> Some (var2_def rname) in
	  VarDecl2 (us, [(x, f_opt')])::decls
      (* some type *)
      | Vcform.TypeVar s ->
	  let f_opt' = match f_opt with
	  |  Some f -> 
	      let _ = add_used_vars f in
	      Some (convert env f)
	  | _ -> None in
	  VarDecl1 ([], [(x, f_opt')])::decls
      (* reference *)
      | Vcform.TypeObjRef t ->
	  let f_opt' = match f_opt with
	  |  Some f -> 
	      let _ = add_used_vars f in
	      Some (mk_and [var1_def t; convert env f])
	  | _ -> Some (var1_def t) in
	  VarDecl1 (us, [(x, f_opt')])::decls
      (* Boolean variable *)
      | Vcform.TypeBool ->
	  VarDecl0 [x]::decls
      (* pointer-valued field *) 
      |	Vcform.TypeFun ([Vcform.TypeObjRef t1 as tt1], Vcform.TypeObjRef t2 as tt2) ->
	  (match f_opt with
	  (* non-derived field *)
	  | None ->
	      let v1 = "v1"
	      and v2 = "v2" in
	      let decl = match mode with
	      |	Ws2s ->
		  mk_or [mk_and [mk_null (mk_var1 v1); mk_null (mk_var1 v2)];
			 mk_and [mk_type (mk_var1 v1) t1; mk_type (mk_var1 v2) t2;
				 mk_elem (mk_var1 v1) heap_var; mk_elem (mk_var1 v2) heap_var;
				 mk_pred eq1_pred [Term1 (mk_var1 v2); 
						   Term1 (mk_succ (mk_var1 v1) t1 (nnode t1) x)]]]
	      |	_ ->
		  finalize env q1_guard q2_guard (
		  mk_or [mk_and [mk_null (mk_var1 v1); mk_null (mk_var1 v2)];
			 mk_and [mk_not (mk_null (mk_var1 v1)); mk_eq1 (mk_plus (mk_var1 v1) 1) (mk_var1 v2)]])
	      in PredDecl (x, [VarPar1 [(v1, None);(v2, None)]], decl)::decls
	  (* derived field *)
	  | Some (Vcform.Binder (Vcform.Lambda, [(v1, _); (v2, _)], fdef) as f) ->
	      let decl = 
		mk_and [mk_impl (mk_null (mk_var1 v1)) (mk_null (mk_var1 v2));
			convert (((v1, Vcform.TypeObjRef t1), None)::((v2, Vcform.TypeObjRef t2), None)::env) fdef] 
	      in
	      let _ = add_used_vars f in
	      PredDecl (x, [VarPar1 [(v1, None); (v2, None)]], decl)::decls
	  | _ -> failwith ("Monaconvert: unsupported field constraint for field " ^ x))
      (* Boolean field *) 
      |	Vcform.TypeFun ([Vcform.TypeObjRef t1], Vcform.TypeBool) ->
	  let v1 = "v1"
	  and xset = "$$" ^ x in 
	  (match mode with 
	  | Ws2s ->
	    VarDecl2 (us, [(xset, Some (mk_sub (mk_var2 xset) heap_var))])::
	      PredDecl (x, [VarPar1 [(v1, None)]], 
			mk_and [mk_type (mk_var1 v1) t1; mk_not (mk_null (mk_var1 v1)); 
				mk_elem (mk_var1 v1) (mk_var2 xset)])::decls
	  | _ -> VarDecl2 (us, [(xset, None)])::
	      PredDecl (x, [VarPar1 [(v1, None)]], 
			mk_elem (mk_var1 v1) (mk_var2 xset))::decls)
      | _ -> decls 
    else decls
  in
  let res = (List.fold_left process_env_decl [] env) in
  res


(* convert vcform to monaform and generate all auxiliary declarations *)

let monaconvert env records f =
  let mk_null v = mk_pred null_pred [Term1 v] in
  let mona_form0, env = convert_vcform_rewrite_derived env f in
  let convert_ws2s records =
    let mk_sometype v =
      mk_or (List.map (fun (rname, _) -> mk_type v rname) records) in
    let q1_guard v = mk_and [mk_sometype (mk_var1 v); mk_elem (mk_var1 v) heap_var] in
    let q2_guard v = mk_sub (mk_var2 v) heap_var in
    let convert env f = finalize env q1_guard q2_guard (fst (convert_vcform env f)) in
    let mk_type_decl rname fields =
      let type_decl = TypeDecl (rname, [(nnull rname, []); (nnode rname, fields)]) in
      type_decl
    in
    let process_record (rname, fields) 
	(gtroots, nulls, type_decls) =
      let type_decl = mk_type_decl rname fields in
      ((String.uppercase (gtype_root rname), [(gtype_root rname, rname)])::gtroots,
       mk_variant (mk_var1 "v") heap rname (nnull rname)::nulls,
       type_decl::type_decls)
    in
    let types, null_def, type_decls = 
      List.fold_right process_record records ([], [], []) in
    let bb_decls = match types with
    | [(_, [(_, ty)])] -> 
	[TypeDecl (heap_type, [(heap_empty, []);
			       (heap_bbtree, [(heap_bbroot, ty); (heap_next, heap_type)])])]
    | _ -> [TypeDecl (graph_type, types);
	    TypeDecl (heap_type, [(heap_empty, []);
				  (heap_bbtree, [(heap_bbroot, graph_type); (heap_next, heap_type)])])] 
    in
    let univs_decl = Universe [(univ, Some (UnivTree heap_type))] in
    let tree_decl = TreeDecl ([univ], [(heap, Some (mk_eq1 (mk_treeroot heap_var) (mk_root1 (Some univ))))]) in
    let null_decl = PredDecl (null_pred, [VarPar1 [("v", None)]], mk_and [mk_elem (mk_var1 "v") heap_var; mk_or null_def]) in
    (Ws2s, type_decls @ bb_decls @ [univs_decl; tree_decl; null_decl], mk_sometype, q1_guard, q2_guard)
  in
  let convert_ws1s rname (fld, _) =
    let mk_sometype v = mk_true in
    let q1_guard v = mk_true in
    let q2_guard v = mk_true in 
    let null_set = "$NullSet" in
    let null_set_decl = 
      VarDecl2 ([], 
		[(null_set, Some (mk_ex1 ["v"] (mk_and [mk_elem (mk_var1 "v") (mk_var2 null_set);
							mk_all1 ["v'"] (mk_not (mk_eq1 (mk_var1 "v'") (mk_plus (mk_var1 "v") 1)))])))]) in
    let null_decl =  PredDecl (null_pred, [VarPar1 [("v", None)]], mk_elem (mk_var1 "v") (mk_var2 null_set)) in
    (M2l_str, [null_set_decl; null_decl], mk_sometype, q1_guard, q2_guard)
  in
  let records_wo_derived_fields = 
    List.map (fun (rname, fields) ->
      (rname, List.fold_right 
	 (fun fld bb_fields -> 
	   match fld with
	   | ((fname, Vcform.TypeFun (_, Vcform.TypeObjRef ftype)), false) -> 
	       (fname, ftype)::bb_fields
	   | _ -> bb_fields
	 ) fields [])) records 
  in
  let mode, decls, mk_sometype, q1_guard, q2_guard = 
    match records_wo_derived_fields with
    | [(rname, [field])] -> convert_ws1s rname field 
    | _ -> convert_ws2s records_wo_derived_fields
  in
  let mona_form = finalize env q1_guard q2_guard mona_form0 in 
  let eq1_decl = 
    PredDecl (eq1_pred, [VarPar1 [("v1", None);("v2", None)]], 
	      mk_or [mk_eq1 (mk_var1 "v1") (mk_var1 "v2"); 
		     mk_and [mk_null (mk_var1 "v1");mk_null (mk_var1 "v2")]])
  in
  let elem_decl = PredDecl (elem_pred, [VarPar1 [("v", None)]; VarPar2 [("S", None)]],
			      mk_or [mk_elem (mk_var1 "v") (mk_var2 "S"); 
				     mk_and [mk_pred null_pred [Term1 (mk_var1 "v")]; 
					     mk_ex1 ["$v"] (mk_and [mk_pred null_pred [Term1 (mk_var1 "$v")];
								    mk_elem (mk_var1 "$v") (mk_var2 "S")])]])   
  and env_decls = convert_env mk_sometype q1_guard q2_guard mode env (fv mona_form0) in
  (mode, decls @ eq1_decl :: elem_decl :: env_decls, mona_form)


    

