let infile  = "in.mona"
let outfile = "mona-out.txt"
let mona = "mona"
let valid_formula = "Formula is valid"
let invalid_formula = "Formula is unsatisfiable"
let counter_example = "A counter-example"

open Bohneutil
open Monaform
open Monaprint

exception Internal of string
    
let fileToLine fn =
  let chn = open_in fn in
  let str = input_line chn in
  close_in chn;
  str
  

type lineParseResult = Nothing | ParsedLine of string      
    
let parse_line s = 
  if String.contains s '=' then ParsedLine s
  else Nothing
      
let parse_counterexample fn = 
  let chn = open_in fn in
  let firstLine = input_line chn in
  let expectedStr = "A counter-example of least length" in
  let leftContains str substr = 
    try (String.sub str 0 (String.length substr) = substr) with
      Invalid_argument _ -> false in
  let res = ref "\nFailed to retrieve a counterexample.\n" in
  let line = ref "" in
  if leftContains firstLine expectedStr then begin
    try begin        
      while (parse_line !line = Nothing) do
        line := input_line chn
      done;
      res := !line ^ "\n";
      while (parse_line !line <> Nothing) do
        (match (parse_line !line) with
          ParsedLine s -> res := !res ^ s ^ ", "
        | Nothing -> failwith "Mona.parseCounterexample: BUG");
        line := input_line chn
      done;
      res := !res ^ "\n"
    end with End_of_file -> ()
  end else ();
  close_in chn;
  !res

    
let parse_output_valid str =
  if str = valid_formula then true
  else if str = invalid_formula then false
  else if (try (String.sub str 0 (String.length counter_example) = counter_example) with
    Invalid_argument _ -> false) then false
  else raise (Internal ("Mona returned " ^ str))
      
let run_mona prog =
  let chn = open_out infile in
  let _ = print_prog chn prog; close_out chn in
  let startTime = Unix.gettimeofday () in
  ignore (Sys.command (mona ^ " -q " ^ infile ^ "> " ^ outfile));
  let time = Unix.gettimeofday () -. startTime in
  ()

let valid mode preamble f = 
  let _ = run_mona (mode, preamble@[FormDecl f]) in 
  let res = parse_output_valid (fileToLine outfile) in
  res
   
let get_counterexample mode all_sets decls f =
  let fvs = String.concat "\n"
      (List.map (fun x -> 
        ("var2 "^(Util.replace_dot_with_uscore x)^";")) 
         (Util.remove_dups all_sets)) in
  let time = run_mona (mode,decls@[FormDecl f]) in 
  parse_counterexample outfile

    
